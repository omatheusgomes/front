// js/dashboard.js
// Renderiza e controla o painel dentro de #view-generic (SPA)

export function initDashboard(root) {
  // marca a view genérica como "dashboard" (CSS só ativa quando .is-active também está presente)
  root.classList.add('dashboard');

  root.innerHTML = `
    <section class="dash-toolbar">
      <label class="field">
        <span>Início</span>
        <input type="date" id="d-start">
      </label>
      <label class="field">
        <span>Fim</span>
        <input type="date" id="d-end">
      </label>
      <button class="btn btn-primary" id="d-apply">Filtrar</button>
    </section>

    <section class="kpi-grid">
      <article class="kpi-card"><div class="kpi-title">Abertos</div><div class="kpi-value" id="kpiOpen">0</div></article>
      <article class="kpi-card"><div class="kpi-title">Aguardando</div><div class="kpi-value" id="kpiWait">0</div></article>
      <article class="kpi-card"><div class="kpi-title">Finalizados</div><div class="kpi-value" id="kpiClosed">0</div></article>
      <article class="kpi-card"><div class="kpi-title">Novos contatos</div><div class="kpi-value" id="kpiNew">0</div></article>
      <article class="kpi-card"><div class="kpi-title">Tempo médio resposta</div><div class="kpi-value" id="kpiAvgResp">0m</div></article>
      <article class="kpi-card"><div class="kpi-title">Tempo médio espera</div><div class="kpi-value" id="kpiAvgWait">0m</div></article>
    </section>

    <section class="chart-grid">
      <div class="chart-card">
        <h3>Conversas por agente</h3>
        <div class="chart-body"><canvas id="chartAgents"></canvas></div>
      </div>
      <div class="chart-card">
        <h3>Conversas por dia</h3>
        <div class="chart-body"><canvas id="chartDaily"></canvas></div>
      </div>
    </section>
  `;

  // Mocks iniciais
  const data = getMockData();
  updateKpis(data.kpis);
  drawCharts(data);

  // Filtro (no futuro, chamar seu backend aqui)
  document.getElementById('d-apply').addEventListener('click', () => {
    const filtered = getMockData(); // trocar por fetch(...)
    updateKpis(filtered.kpis);
    drawCharts(filtered);
  });
}

/* ---------- helpers ---------- */
function updateKpis(k) {
  setText('kpiOpen', k.open);
  setText('kpiWait', k.waiting);
  setText('kpiClosed', k.closed);
  setText('kpiNew', k.newContacts);
  setText('kpiAvgResp', k.avgResponse);
  setText('kpiAvgWait', k.avgWait);
}
function setText(id, v){ const el = document.getElementById(id); if (el) el.textContent = v; }

let charts = { agents: null, daily: null };

function drawCharts(d) {
  // destruir gráficos antigos para não “derreter”
  charts.agents?.destroy();
  charts.daily?.destroy();

  const tick = getCss('--ink-700').trim() || '#9aa1b4';

  charts.agents = new Chart(
    document.getElementById('chartAgents').getContext('2d'),
    {
      type: 'bar',
      data: {
        labels: d.agents.labels,
        datasets: [{
          label: 'Conversas',
          data: d.agents.values,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: tick } } },
        scales: {
          x: { ticks: { color: tick } },
          y: { ticks: { color: tick }, beginAtZero: true }
        }
      }
    }
  );

  charts.daily = new Chart(
    document.getElementById('chartDaily').getContext('2d'),
    {
      type: 'line',
      data: {
        labels: d.daily.labels,
        datasets: [{
          label: 'Conversas/dia',
          data: d.daily.values,
          tension: .3,
          borderWidth: 2,
          fill: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: tick } } },
        scales: {
          x: { ticks: { color: tick } },
          y: { ticks: { color: tick }, beginAtZero: true }
        }
      }
    }
  );
}

function getCss(varName){
  return getComputedStyle(document.documentElement).getPropertyValue(varName);
}

/* ---------- mocks (troque por dados reais depois) ---------- */
function getMockData(){
  return {
    kpis: {
      open: 14,
      waiting: 0,
      closed: 19,
      newContacts: 4,
      avgResponse: '11m',
      avgWait: '17m'
    },
    agents: {
      labels: ['Alex','João','Maria','Ana','Paulo','Rafa'],
      values: [14, 2, 3, 8, 4, 6]
    },
    daily: {
      labels: ['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
      values: [1, 0, 3, 2, 1, 0, 7]
    }
  };
}
