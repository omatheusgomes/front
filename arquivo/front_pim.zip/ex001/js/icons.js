// icons.js — inliner simples para SVGs do Lucide
async function loadIcon(name) {
  const res = await fetch(`icons/${name}.svg`, { cache: 'force-cache' });
  if (!res.ok) throw new Error('Não foi possível carregar ' + name);
  const svgText = await res.text();
  const div = document.createElement('div');
  div.innerHTML = svgText.trim();
  const svg = div.querySelector('svg');
  if (!svg) throw new Error('SVG inválido: ' + name);

  // Lucide já usa stroke="currentColor". Garantimos os atributos padrão:
  svg.setAttribute('width', '100%');
  svg.setAttribute('height', '100%');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  return svg;
}

async function hydrateIconEl(el) {
  const name = el.getAttribute('data-icon');
  if (!name) return;
  try {
    const svg = await loadIcon(name);
    // limpa filhos antigos
    el.innerHTML = '';
    el.appendChild(svg);
  } catch(e) {
    console.error(e);
  }
}

function initIcons() {
  const all = document.querySelectorAll('.icon[data-icon]');
  all.forEach(hydrateIconEl);

  // Observa mudanças no atributo data-icon (ex.: moon -> sun)
  document.addEventListener('icon-change', e => {
    const el = e.target;
    if (el && el.classList && el.classList.contains('icon')) {
      hydrateIconEl(el);
    }
  });

  // Ouvir alterações de atributo diretamente
  const observer = new MutationObserver(muts => {
    muts.forEach(m => {
      if (m.type === 'attributes' && m.attributeName === 'data-icon') {
        hydrateIconEl(m.target);
      }
    });
  });
  document.querySelectorAll('.icon[data-icon]').forEach(el => observer.observe(el, { attributes: true }));
}

document.addEventListener('DOMContentLoaded', initIcons);