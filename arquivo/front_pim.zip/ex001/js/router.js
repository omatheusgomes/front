// js/router.js
import { initDashboard } from './dashboard.js';

const routes = {
  chamados: {
    title: 'Chamados',
    enter: () => {
      setTopbar('Chamados');
      setSidebarActive('chamados');
      toggleTabs(true);
      toggleToolbar(true);
      showView('chamados');
    },
  },

  dashboard: {
    title: 'Dashboard',
    enter: () => {
      setTopbar('Dashboard');
      setSidebarActive('dashboard');
      toggleTabs(false);
      toggleToolbar(false);
      showView('generic');                 // ativa a view genérica
      const vg = document.getElementById('view-generic');
      vg.innerHTML = '';                   // limpa conteúdo anterior
      initDashboard(vg);                   // injeta o dashboard
    },
  },

  respostas: { title: 'Respostas Rápidas', enter: () => renderGeneric('Respostas Rápidas', `
      <div class="module-card">Crie e gerencie atalhos de mensagens.</div>
  `)},
  contatos: { title: 'Contatos', enter: () => renderGeneric('Contatos', `
      <div class="module-card">Lista de contatos e detalhes.</div>
  `)},
  tags: { title: 'Tags', enter: () => renderGeneric('Tags', `
      <div class="module-card">Organize categorias de tags.</div>
  `)},
  openai: { title: 'OpenAI', enter: () => renderGeneric('OpenAI', `
      <div class="module-card">Experimentos com IA / automações.</div>
  `)},
  conexoes: { title: 'Conexões', enter: () => renderGeneric('Conexões', `
      <div class="module-card">Telegram/WhatsApp e outros conectores.</div>
  `)},
  usuarios: { title: 'Usuários', enter: () => renderGeneric('Usuários', `
      <div class="module-card">Membros, permissões e equipes.</div>
  `)},
  config: { title: 'Configurações', enter: () => renderGeneric('Configurações', `
      <div class="module-card">Preferências do sistema.</div>
  `)},
};

function renderGeneric(title, inner) {
  setTopbar(title);
  setSidebarActive(getHashRoute());
  toggleTabs(false);
  toggleToolbar(false);
  showView('generic');

  const vg = document.getElementById('view-generic');
  vg.classList.remove('dashboard');     // evita estilos do dashboard em outras telas
  vg.innerHTML = `
    <div class="module-wrap">
      <h2 class="module-title">${title}</h2>
      <p class="module-sub">Protótipo da tela (frontend).</p>
      ${inner}
    </div>
  `;
}

/* ---------- helpers SPA ---------- */
function setTopbar(text){ const el = document.getElementById('topbarTitle'); if (el) el.textContent = text; }
function toggleTabs(show){ const el = document.getElementById('tabs-status'); if (el) el.style.display = show ? 'flex' : 'none'; }
function toggleToolbar(show){ const el = document.getElementById('toolbar'); if (el) el.style.display = show ? 'flex' : 'none'; }

/* VISIBILIDADE das views: usa a classe .is-active (alinhado ao CSS) */
function showView(name){
  const vc = document.getElementById('view-chamados');
  const vg = document.getElementById('view-generic');

  if (name === 'chamados'){
    // some qualquer resquício do dashboard
    vg.classList.remove('is-active', 'dashboard');
    vg.innerHTML = '';
    vc.classList.add('is-active');
  } else {
    vc.classList.remove('is-active');
    vg.classList.add('is-active');
  }
}

function setSidebarActive(route){
  document.querySelectorAll('.menu .menu-item').forEach(a=>{
    const r = a.getAttribute('data-route');
    if (r === route) { a.classList.add('active'); a.setAttribute('aria-current','page'); }
    else { a.classList.remove('active'); a.removeAttribute('aria-current'); }
  });
}
function getHashRoute(){ const h = (location.hash||'#/chamados').replace(/^#\//,''); return routes[h] ? h : 'chamados'; }
function handleRoute(){ routes[getHashRoute()].enter(); }

window.addEventListener('hashchange', handleRoute);
document.addEventListener('DOMContentLoaded', handleRoute);
