// login.js
import { login, saveSession } from './services/auth.js';

const form = document.getElementById('login-form');

form?.addEventListener('submit', async (e) => {
  // Intercepta o submit para simular login e salvar "sessão"
  e.preventDefault();

  const username = document.getElementById('usuario').value.trim();
  const password = document.getElementById('senha').value;

  try {
    const data = await login({ username, password }); // mock hoje; real depois
    saveSession(data);

    // Redireciona para a tela de chamados (ajuste o nome se for dashboard.html)
    window.location.href = 'chamados.html';
  } catch (err) {
    alert(err?.details?.message || err.message || 'Erro ao autenticar.');
  }
});
