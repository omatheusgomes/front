// theme.js — alterna claro/escuro, persiste e troca a lua/sol no "thumb"
const STORAGE_KEY = 'nexhelp_theme'; // 'light' | 'dark'

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  // troca o ícone da alavanca
  const thumbIcon = document.getElementById('themeThumbIcon');
  if (thumbIcon) {
    thumbIcon.setAttribute('data-icon', theme === 'dark' ? 'sun' : 'moon');
    // Re-render do SVG (icons.js cuida disso ao observar mutação)
    thumbIcon.dispatchEvent(new CustomEvent('icon-change'));
  }
}

function getInitialTheme() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === 'light' || saved === 'dark') return saved;
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  return prefersDark ? 'dark' : 'light';
}

const theme = getInitialTheme();
applyTheme(theme);

const toggleBtn = document.getElementById('themeToggle');
if (toggleBtn) {
  toggleBtn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem(STORAGE_KEY, next);
    applyTheme(next);
  });
}