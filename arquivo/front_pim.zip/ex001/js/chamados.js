// js/chamados.js

/* ---------- Elementos ---------- */
const els = {
  tabs: document.getElementById('tabs-status'),

  onlyMine: document.getElementById('onlyMine'),
  btnQueues: document.getElementById('btnQueues'),
  queuesMenu: document.getElementById('queuesMenu'),
  btnNovo: document.getElementById('btnNovo'),

  listAtendendo: document.getElementById('list-atendendo'),
  listAguardando: document.getElementById('list-aguardando'),
  listResolvidos: document.getElementById('list-resolvidos'),

  subtabs: document.querySelector('.subtabs'),

  chatBody: document.getElementById('chatBody'),
  chatTitle: document.getElementById('chatTitle'),
  chatSub: document.getElementById('chatSub'),
  composerInput: document.getElementById('composerInput'),
  composerSend: document.getElementById('composerSend'),
  headerAction: document.getElementById('btnHeaderAction'),
};

/* ---------- Estado ---------- */
const state = {
  tab: 'abertos',          // abertos | resolvidos
  subtab: 'atendendo',     // atendendo | aguardando
  onlyMine: false,
  activeChatId: null,
};

/* ---------- Seed de exemplo (substituir por API depois) ---------- */
const seed = {
  atendendo: [
    { id: 201, title: 'Talagaço',  last: 'Pedido confirmado • 1x ÁGUA COM GÁS…', when:'10:51', status:'atendendo' },
    { id: 202, title: 'Eli Elton', last: 'Enviei os documentos, pode verificar?', when:'Ontem', status:'atendendo' },
  ],
  aguardando: [
    { id: 102, title: 'Junior Oliveira', last: 'Aguardando retorno do financeiro…', when:'09:20', status:'aguardando' },
    { id: 101, title: 'Novo contato',    last: 'Novo chamado criado',              when:'agora', status:'aguardando' },
  ],
  resolvidos: [
    { id: 301, title: 'Instalação concluída', last:'Ticket fechado por Alex', when:'Ontem', status:'resolvido' },
  ],
};

/* ---------- Toolbar ---------- */
els.onlyMine?.addEventListener('change', () => {
  state.onlyMine = els.onlyMine.checked;
  renderLists();
});
els.btnNovo?.addEventListener('click', () => {
  alert('Abrir modal de novo chamado (protótipo).');
});
els.btnQueues?.addEventListener('click', (e) => {
  e.stopPropagation();
  els.btnQueues.closest('.queues').classList.toggle('open');
});
document.addEventListener('click', () => {
  const q = document.querySelector('.queues.open'); if (q) q.classList.remove('open');
});

/* ---------- Tabs principais ---------- */
els.tabs.querySelectorAll('.tab').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    els.tabs.querySelectorAll('.tab').forEach(b=>b.classList.remove('is-active'));
    btn.classList.add('is-active');
    state.tab = btn.dataset.tab; // abertos | resolvidos
    els.subtabs.style.display = state.tab === 'abertos' ? 'flex' : 'none';
    clearChat();
    renderLists();
  });
});

/* ---------- Subtabs (delegação) ---------- */
els.subtabs.addEventListener('click', (e)=>{
  const b = e.target.closest('.subtab');
  if (!b) return;
  els.subtabs.querySelectorAll('.subtab').forEach(x=>x.classList.remove('is-active'));
  b.classList.add('is-active');
  state.subtab = b.dataset.subtab; // atendendo | aguardando
  renderLists();
});

/* ---------- Render das listas ---------- */
function renderLists(){
  // limpa
  [els.listAtendendo, els.listAguardando, els.listResolvidos].forEach(ul => ul.innerHTML = '');

  if (state.tab === 'resolvidos'){
    seed.resolvidos.forEach(row => els.listResolvidos.appendChild(makeItem(row)));
    showPane('resolvidos');
    return;
  }

  seed.atendendo.forEach(row  => els.listAtendendo.appendChild(makeItem(row)));
  seed.aguardando.forEach(row => els.listAguardando.appendChild(makeItem(row)));
  showPane(`abertos|${state.subtab}`);
}

function showPane(key){
  const map = {
    'abertos|atendendo':  [els.listAtendendo, els.listAguardando, els.listResolvidos],
    'abertos|aguardando': [els.listAguardando, els.listAtendendo, els.listResolvidos],
    'resolvidos':         [els.listResolvidos, els.listAtendendo, els.listAguardando],
  };
  const [show, hide1, hide2] = map[key];
  show.classList.remove('is-hidden');
  hide1.classList.add('is-hidden');
  hide2.classList.add('is-hidden');
}

function makeItem(row){
  const li = document.createElement('li');
  li.className = 'conv-item';
  li.dataset.chatId = row.id;
  li.innerHTML = `
    <span class="conv-avatar icon" data-icon="book-user"></span>
    <div class="conv-main">
      <div class="conv-row">
        <strong class="conv-name">${esc(row.title)}</strong>
        <span class="conv-time">${row.when}</span>
      </div>
      <div class="conv-row">
        <span class="conv-preview">${esc(row.last)}</span>
        <span class="conv-actions">${actionsHTML(row.status)}</span>
      </div>
    </div>
  `;
  return li;
}

function actionsHTML(status){
  if (status === 'aguardando') return `
    <button class="xs-btn" data-act="aceitar">Aceitar</button>
    <button class="xs-btn" data-act="ignorar">Ignorar</button>`;
  if (status === 'atendendo')  return `<button class="xs-btn" data-act="resolver">Resolver</button>`;
  return `<button class="xs-btn" data-act="reabrir">Reabrir</button>`;
}

/* ---------- Delegação de clique nas listas ---------- */
document.querySelector('.inbox').addEventListener('click', (e)=>{
  const btn = e.target.closest('.xs-btn');
  if (btn){
    e.stopPropagation();
    alert(`Ação: ${btn.dataset.act}`);
    return;
  }
  const li = e.target.closest('.conv-item');
  if (!li) return;
  document.querySelectorAll('.conv-item').forEach(x=>x.classList.remove('is-active'));
  li.classList.add('is-active');
  openChat(Number(li.dataset.chatId), li.querySelector('.conv-name')?.textContent || 'Contato');
});

/* ---------- Chat ---------- */
function openChat(id, title){
  state.activeChatId = id;
  els.chatTitle.textContent = title;
  els.chatSub.textContent = `ID ${id}`;
  els.chatBody.innerHTML = '';
  addMsg({ me:false, text:'Mensagem do cliente…', date:Date.now()-120000 });
  addMsg({ me:true,  text:'Olá! Estou verificando seu chamado.', date:Date.now()-60000 });
}

function addMsg(m){
  const el = document.createElement('div');
  el.className = `msg ${m.me ? 'msg-out' : 'msg-in'}`;
  el.innerHTML = `<div class="msg-bubble">${esc(m.text)}</div><div class="msg-time">${fmt(m.date)}</div>`;
  els.chatBody.appendChild(el);
  els.chatBody.scrollTop = els.chatBody.scrollHeight;
}

els.composerInput.addEventListener('input', ()=>{
  els.composerSend.disabled = !els.composerInput.value.trim();
});
els.composerSend.addEventListener('click', ()=>{
  const t = els.composerInput.value.trim(); if (!t || !state.activeChatId) return;
  addMsg({ me:true, text:t, date:Date.now() });
  els.composerInput.value = '';
  els.composerSend.disabled = true;
});

/* ---------- Utils ---------- */
const esc = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const fmt = ms => new Date(ms).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

/* boot */
renderLists();

function clearChat(){
  els.chatTitle.textContent = 'Selecione um chamado';
  els.chatSub.textContent = '—';
  els.chatBody.innerHTML = '';
  state.activeChatId = null;
}
