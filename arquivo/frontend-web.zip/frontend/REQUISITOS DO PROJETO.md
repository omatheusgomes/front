## 1. Trechos transcritos relacionados ao desenvolvimento do sistema (ênfase em web)

### 1.1 Objetivo geral

> **OBJETIVO GERAL**
> Desenvolver um sistema de suporte técnico inteligente, utilizando recursos como por
> exemplo FAQs dinâmicas baseadas no histórico de chamados e ferramentas de apoio ao
> desenvolvimento com Inteligência Artificial, de forma a otimizar o atendimento e promover
> autonomia dos usuários. A LGPD será aplicada a todos os dados pessoais tratados no
> sistema. O desenvolvimento ocorrerá como continuidade do PIM III do semestre
> anterior, no qual foi realizado o levantamento de requisitos e demais procedimentos
> relacionados à análise do sistema. 

---

### 1.2 Objetivos específicos (partes técnicas)

> **Objetivos Específicos**
> • Aplicar os princípios da orientação a objetos no refinamento da arquitetura do sistema
> (Projeto de Sistemas Orientado a Objetos).
>
> • Implementar as funcionalidades usando C# e ASP.NET, aplicando técnicas modernas de
> programação (POO II e Tópicos Especiais de POO).
>
> • Desenvolver interfaces funcionais para desktop, web e mobile, com foco em experiência
> do usuário (Desenvolvimento para Internet).
>
> • Planejar e controlar o cronograma e os riscos do projeto (Gerenciamento de Projetos de
> Software).
>
> • Aplicar práticas de versionamento, testes e controle de qualidade do software (Gestão da
> Qualidade).
>
> • Considerar aspectos de inclusão e diversidade no design e uso do sistema (Relações
> Étnico-Raciais e Afrodescendência).
>
> • Avaliar estratégias de viabilidade e sustentabilidade do projeto (Empreendedorismo).
>
> • Usar recursos de IA (inteligência Artificial) como apoio ao desenvolvimento,
> especialmente na elaboração de conteúdos como FAQ ou documentação, analisando
> diferentes opções do mercado
>
> • Desenvolvimento de aplicativo mobile. (Tópicos Especiais de POO). 

---

### 1.3 Disciplinas contempladas (base técnica)

> **DISCIPLINAS CONTEMPLADAS**
> • Base: Programação Orientada a Objetos II, Desenvolvimento de Software para
> Internet, Tópicos Especiais de Programação Orientada a Objetos, Projeto de
> Sistemas Orientado a Objetos, Gerenciamento de Projetos de Software.
>
> • Complementar: Empreendedorismo, Gestão da Qualidade. 

---

### 1.4 Contextualização – cenário do sistema

> **Contextualização**
> Uma empresa de médio porte possui um setor de TI responsável por atender
> solicitações internas de suporte técnico. Atualmente, todas as requisições são recebidas por
> e-mail ou telefone, o que gera dificuldades no controle dos chamados, atrasos e falhas na
> priorização. A empresa deseja adotar um sistema integrado, onde os colaboradores possam
> registrar suas solicitações e a IA possa sugerir soluções automáticas ou encaminhar ao
> técnico adequado com base no histórico de chamados e complexidade do problema. 

---

### 1.5 Tecnologias e diretrizes (tecnologia, incluindo web)

> **Tecnologias e Diretrizes:**
> • Desktop: Interface em C# com Windows Forms, WPF para gestão administrativa do
> sistema, Blazor etc.
>
> • Web: ASP.NET e C# para a aplicação web responsiva.
>
> • Mobile: Desenvolvimento para Android, permitindo que usuários abram chamados via
> aplicativo.
>
> • Banco de Dados: MS SQL Server hospedado em Windows Server.
>
> • IA: Os alunos poderão utilizar ferramentas de IA generativa como apoio à elaboração
> de FAQ, sugestões de resposta automática e documentação, simulando
> funcionalidades inteligentes com base em dados históricos. 

---

### 1.6 Exigência de LGPD

> Como muitos dos usuários são pessoas físicas, há uma manipulação dados
> pessoais, logo o projeto deve estar aderente a LGPD Lei geral de proteção de dados. 

---

### 1.7 Escopo funcional e entregáveis técnicos do sistema

> O sistema deve possuir total controle das principais funcionalidades (não precisa
> ser um sistema que atenda a todas as características de um sistema de mercado
> completo). Devem ser apresentados alguns relatórios parciais, diários ou consolidados
> mensalmente, gráficos, alertas etc.
>
> Recomenda-se planejar o sistema para ser desenvolvido em no máximo quatro
> meses após ser especificado de acordo com o tamanho da equipe.
>
> Com base nestas informações, cada grupo deverá:
>
> 1. Código-fonte funcional, comentado e validado com scripts de testes.
> 2. Interfaces completas e operacionais para desktop, web e mobile.
> 3. Relatórios gerenciais, painéis gráficos e alertas implementados.
> 4. Scripts SQL do banco de dados e plano de implantação em ambiente Windows
>    Server.
> 5. Plano de homologação e roteiro de testes executado.
> 6. Manual de usuário e plano de treinamento para uso do sistema.
> 7. infográficos devem ilustrar o fluxo dos chamados, categorização, ou uso da IA no
>    processo de suporte técnico, facilitando o entendimento visual da regra de
>    negócio. 

---

### 1.8 Programação Orientada a Objetos II – requisitos técnicos

> **2. PROGRAMAÇÃO ORIENTADA A OBJETOS II**
>
> Apresentar os métodos e tecnologias adotadas pelo paradigma da orientação a
> objetos, para a aplicação em um desenvolvimento de sistemas do porte proposto no projeto,
> com base em referências bibliográficas devidamente citadas e relacionadas.
>
> Descrever o processo de utilização desses métodos e tecnologias no suporte às
> atividades de desenvolvimento de projeto de software, que trate das questões relacionadas
> às demandas do presente sistema.
>
> Aplicar as técnicas de programação orientada a objetos, para a elaboração do
> sistema proposto pelo grupo.
>
> Os requisitos da disciplina para o PIM são:
>
> a) Implementação da Aplicação:
> Desenvolvimento de uma aplicação desktop utilizando a linguagem C# com uma interface
> gráfica intuitiva e funcional, adequada para o ambiente desktop.
>
> b) Banco de Dados:
> Utilização do Microsoft SQL Server como sistema de gerenciamento de banco de dados,
> garantindo a integridade e eficiência no armazenamento e manipulação dos dados.
>
> c) Operações CRUD:
> Avaliação completa das operações de Create, Read, Update e Delete (CRUD)
> implementadas, considerando a corretude, eficiência e robustez dos processos.
>
> d) Conformidade com a Modelagem:
> Verificação da aderência do projeto aos diagramas de modelagem, incluindo o diagrama de
> classes e o diagrama de entidades e relacionamentos, assegurando que o código segue as
> estruturas definidas na fase de planejamento. 

---

### 1.9 Desenvolvimento de Software para Internet – requisitos (WEB)

> **3. DESENVOLVIMENTO DE SOFTWARE PARA INTERNET**
>
> Apresentar os métodos e tecnologias adotadas para o desenvolvimento de software
> para a Internet, considerando a composição de um desenvolvimento de sistemas do porte
> proposto no projeto, com base em referências bibliográficas devidamente citadas e
> relacionadas.
>
> Descrever o processo de utilização desses métodos e tecnologias no suporte às
> atividades de desenvolvimento de software para a Internet, que trate das questões
> relacionadas às demandas do presente sistema.
>
> Aplicar as técnicas de desenvolvimento de software para a Internet, para a
> composição do sistema proposto pelo grupo.
>
> Os requisitos da disciplina para o PIM são:
> • Apresentação dos resultados obtidos após a realização dos Testes de Usabilidade,
> fornecendo os protótipos previamente desenvolvidos a usuários representativos
> • Desenvolvimento de um sistema Web responsivo
> • Implementação de mecanismos de segurança para controle de acesso (autenticação
> e/ou autorização) 

---

### 1.10 Tópicos Especiais de Programação Orientada a Objetos – requisitos

> **4. TÓPICOS ESPECIAIS DE PROGRAMAÇÃO ORIENTADA A OBJETOS**
>
> Apresentar os métodos e tecnologias adotadas para a adoção de tópicos especiais de
> programação orientada a objetos, considerando a composição de um desenvolvimento de
> sistemas do porte proposto no projeto, com base em referências bibliográficas devidamente
> citadas e relacionadas.
>
> Descrever o processo de utilização desses métodos e tecnologias no suporte às
> atividades de utilização de tópicos especiais de programação orientada a objetos, que trate
> das questões relacionadas às demandas do presente sistema.
>
> Aplicar tópicos especiais de programação orientada a objetos, para a composição do
> sistema proposto pelo grupo.
>
> Os requisitos da disciplina para o PIM são:
> • Implementação de Classes em conformidade com o Diagrama de Classe a ser
> apresentado na documentação do PIM IV
> • Aplicação dos conceitos de Herança, Polimorfismo e Abstração
> • Implementação de Testes de Unidade (Testes Automatizados) 

---

### 1.11 Projeto de Sistemas Orientado a Objetos – requisitos

> **5. PROJETO DE SISTEMAS ORIENTADO A OBJETOS**
>
> Os requisitos da disciplina para o PIM são:
> Demonstrar a partir das funcionalidades do sistema, os modelos para o Projeto de Sistemas
> O O, que deverão ter os diagramas de:
> 1-CLASSE de IMPLEMENTAÇÃO.
> 2- Sequência.
> 3-Colaboração.
> Organizados em pacotes afins. 

---

### 1.12 Gestão da Qualidade – requisito ligado ao sistema

> **8. GESTÃO DA QUALIDADE**
>
> O requiisto da disciplina para o PIM é:
>
> Aplicar pelo menos uma ferramenta de gestão da qualidade no sistema desenvolvido,
> apresentando suas características principais e eventuais impactos na qualidade do sistema. 

---

### 1.13 Requisitos essenciais de linguagem e tecnologias (inclui web)

> Trabalhos que não atendam aos requisitos fundamentais de linguagem e de
> tecnologias (orientação a objetos e responsividade) poderão ser reprovados.
>
> Repete-se aqui para ênfase os requisitos essenciais:
> a) Usará o paradigma da orientação a objetos para o sistema, com interface
> gráfica para desktop.
>
> b) A aplicação Web poderá ser desenvolvida com o uso da tecnologia
> ASP.Net com a linguagem C#.
>
> c) A aplicação Mobile será desenvolvida com foco em Android (90%) dos
> clientes. Porém, poderão ser usadas outras tecnologias tais como .Net
> Maui, flutter, python (Kivy, KivyMD, ...) etc.
>
> d) O banco de dados utilizado deverá ser o MS SQL Server, hospedado em
> um servidor Windows Server.
>
> Obviamente, junto destas tecnologias e linguagens, há itens adicionais, como html,
> javascript, jquery, bootstrap, sqlite para o mobile etc. 

---

### 1.14 Observação geral sobre as interfaces (inclui web)

> Observações gerais [...]
> Quem define a regra de negócio é o grupo do PIM, não são os professores. A regra
> de negócio será definida em função das pesquisas e interesses do grupo do PIM. Atentem-
> se que deve haver uma parte visual em desktop, outra em web e outra em mobile, que
> deverá ser definida pela equipe do PIM considerando que terão em torno de 3 a 4 meses
> para desenvolver os programas. Logo, deve ser previsto algo que seja factível. No trabalho,
> deverá ficar clara a contribuição de cada disciplina, o que será evidenciado pelos artefatos
> entregues. 

---

### 1.15 Desenvolvimento do projeto – orientação geral

> **9. DESENVOLVIMENTO DO PROJETO**
>
> Com base na fundamentação teórica desenvolvida em cada disciplina, deverão ser
> elaboradas propostas para cada uma das situações específicas de cada disciplina,
> procurando sempre justificar a adoção da solução proposta, por meio da discussão de suas
> vantagens, viabilidade econômica e/ou disponibilidade da tecnologia. 

---

## 2. Listagem dos requisitos técnicos e itens de programação (foco web)

Agora, juntando tudo, aqui vai uma **lista organizada** só dos pontos técnicos que você precisa cumprir, destacando o que é mais relevante para a **aplicação web**.

### 2.1 Arquitetura geral e tecnologias

* Sistema integrado de suporte técnico com:

  * Módulo desktop (C# + Windows Forms/WPF/Blazor).
  * Módulo web responsivo (ASP.NET + C#).
  * Módulo mobile Android.
* Arquitetura orientada a objetos aplicada em todo o sistema.
* Uso de IA generativa como apoio (FAQ, respostas automáticas, documentação).
* Adequação à LGPD no tratamento dos dados pessoais.
* Banco de dados: **MS SQL Server** hospedado em **Windows Server**.
* Scripts SQL + plano de implantação em ambiente Windows Server.
* Código-fonte funcional, comentado e validado com scripts de testes.
* Operações completas de **CRUD** (Create, Read, Update, Delete) com correção, eficiência e robustez.
* Conformidade do código com:

  * Diagrama de Classes.
  * Diagrama Entidade-Relacionamento.
  * Diagramas de implementação, sequência e colaboração, organizados em pacotes.

---

### 2.2 Requisitos específicos da camada **WEB**

* A aplicação web deve ser:

  * Desenvolvida em **ASP.NET com C#**.
  * **Responsiva** (funcionar bem em diferentes tamanhos de tela).
* Tecnologias complementares citadas:

  * HTML.
  * JavaScript.
  * jQuery.
  * Bootstrap.
* Interface web deve ser **completa e operacional** (não apenas protótipo).
* Deve haver:

  * **Testes de usabilidade** com usuários representativos, partindo de protótipos da interface.
  * **Apresentação dos resultados** desses testes no PIM.
* Implementar **mecanismos de segurança** na web para:

  * Autenticação.
  * Autorização (controle de acesso por perfil/regra).
* A interface web faz parte do conjunto:

  * Interfaces completas para desktop, web e mobile.
  * Relatórios gerenciais, painéis gráficos e alertas (muitos provavelmente via web).
* Responsividade é critério fundamental de aprovação (ligado à disciplina de desenvolvimento web).

---

### 2.3 Requisitos de código e programação (aplicam também à web)

* Aplicar **princípios de orientação a objetos** no refinamento da arquitetura:

  * Herança.
  * Polimorfismo.
  * Abstração.
* Implementar **classes** em conformidade com o Diagrama de Classes.
* Implementar **Testes de Unidade / Testes Automatizados**.
* Garantir aderência entre o código (incluindo camada web) e os modelos UML:

  * Diagrama de Classe de Implementação.
  * Diagramas de Sequência.
  * Diagramas de Colaboração.
* Aplicar práticas de:

  * Versionamento (Git, etc.).
  * Testes.
  * Controle de qualidade do software.

---

### 2.4 Requisitos funcionais de alto nível ligados ao sistema (afetam a web)

* Sistema deve ter:

  * Controle das principais funcionalidades de suporte técnico.
  * Relatórios parciais, diários ou mensais.
  * Gráficos e alertas.
* Entregáveis:

  * Código-fonte comentado e testado.
  * Interfaces completas (desktop, web, mobile).
  * Relatórios e painéis.
  * Manual do usuário.
  * Plano de homologação e roteiro de testes.
  * Infográficos explicando fluxo dos chamados e uso de IA.