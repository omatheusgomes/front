// js/dashboard.js
function css(v){ return getComputedStyle(document.documentElement).getPropertyValue(v).trim(); }

/* ===== KPIs (mock) ===== */
const KPIS = { open:14, waiting:2, closed:1564, avgResponse:'11m', avgWait:'17m' };
document.getElementById('kpi-open').textContent    = KPIS.open;
document.getElementById('kpi-waiting').textContent = KPIS.waiting;
document.getElementById('kpi-closed').textContent  = KPIS.closed;
document.getElementById('kpi-resp').textContent    = KPIS.avgResponse;
document.getElementById('kpi-wait').textContent    = KPIS.avgWait;

/* ===== Filtros (datas) – só na aba Performances ===== */
const dateStart = document.getElementById('dateStart');
const dateEnd   = document.getElementById('dateEnd');
const btnFilter = document.getElementById('btnFilter');
const today = new Date();
const toISO = d => d.toISOString().slice(0,10);
if (dateStart) dateStart.value = toISO(today);
if (dateEnd)   dateEnd.value   = toISO(today);

/* ===== Chart.js ===== */
let perfChart;

function hourLabels(startHour=8, endHour=22){
  const pad = n => String(n).padStart(2,'0');
  const arr = [];
  for (let h=startHour; h<=endHour; h++) arr.push(`${pad(h)}:00–${pad(h)}:59`);
  return arr;
}
function randomSerie(n){ return Array.from({length:n}, ()=> Math.floor(Math.random()*10)+1); }

function buildChart(){
  const labels = hourLabels(8,22);
  const data = randomSerie(labels.length);
  const ctx = document.getElementById('perfChart').getContext('2d');
  const tick = css('--ink-700') || '#9aa1b4';
  if (perfChart) perfChart.destroy();
  perfChart = new Chart(ctx, {
    type:'bar',
    data:{ labels, datasets:[{ label:'Atendimentos', data, borderWidth:2 }] },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{ labels:{ color:tick } } },
      scales:{ x:{ ticks:{ color:tick, maxRotation:45, minRotation:45 } }, y:{ ticks:{ color:tick }, beginAtZero:true } }
    }
  });
}
buildChart();

btnFilter?.addEventListener('click', ()=>{ buildChart(); });

/* ===== Abas: underline + slide super fluido (track) ===== */
const tabs = document.querySelector('.tabs');
const underline = document.getElementById('tabsUnderline');
const tabPerf = document.getElementById('tab-perf');
const tabAtt  = document.getElementById('tab-att');

const panels = document.getElementById('dashPanels');
const track  = document.getElementById('dashTrack');
const panelPerf = document.getElementById('panel-perf');
const panelAtt  = document.getElementById('panel-att');

function moveUnderline(){
  const act = tabs.querySelector('.tab.is-active');
  if (!act) return;
  underline.style.width = act.offsetWidth + 'px';
  underline.style.transform = `translateX(${act.offsetLeft}px)`;
}
window.addEventListener('resize', moveUnderline);
moveUnderline();

function activate(tabName){
  if (tabName === 'perf'){
    tabPerf.classList.add('is-active'); tabPerf.setAttribute('aria-selected','true');
    tabAtt.classList.remove('is-active'); tabAtt.setAttribute('aria-selected','false');
    track.style.transform = 'translateX(0%)';
    panelPerf.removeAttribute('aria-hidden'); panelAtt.setAttribute('aria-hidden','true');
  }else{
    tabAtt.classList.add('is-active'); tabAtt.setAttribute('aria-selected','true');
    tabPerf.classList.remove('is-active'); tabPerf.setAttribute('aria-selected','false');
    track.style.transform = 'translateX(-100%)';
    panelAtt.removeAttribute('aria-hidden'); panelPerf.setAttribute('aria-hidden','true');
    mountAgents();
  }
  moveUnderline();
}

tabPerf.addEventListener('click', ()=> activate('perf'));
tabAtt .addEventListener('click', ()=> activate('att'));

/* ===== Atendentes (lista) — INICIAR VAZIA ===== */
function mountAgents(){
  const rows = []; // sem dados iniciais
  const tbody = document.querySelector('#attTable tbody');
  if (!tbody) return;
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td>${escapeHtml(r.name)}</td>
      <td>${r.total}</td>
      <td>${r.avgWait}</td>
      <td>${r.avgHandle}</td>
      <td>${statusBadge(r.status)}</td>
    </tr>`).join('');
}
function statusBadge(s){
  const isOn = s === 'online';
  const color = isOn ? '#22c55e' : '#9aa1b4';
  const label = isOn ? 'Online' : 'Offline';
  return `<span style="display:inline-flex;align-items:center;gap:.4rem;">
    <span style="inline-size:.6rem;block-size:.6rem;border-radius:999px;background:${color};display:inline-block"></span>${label}
  </span>`;
}
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
