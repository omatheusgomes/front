// js/theme.js
const THEME_KEY = 'nexhelp_theme';
const html = document.documentElement;
const btn  = document.getElementById('themeToggle');
const thumbIcon = document.getElementById('themeThumbIcon');

function getInitial() {
  const saved = localStorage.getItem(THEME_KEY);
  if (saved === 'light' || saved === 'dark') return saved;
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
function apply(theme){
  html.setAttribute('data-theme', theme);
  localStorage.setItem(THEME_KEY, theme);
  if (thumbIcon){
    const want = theme === 'dark' ? 'moon' : 'sun';
    thumbIcon.setAttribute('data-icon', want);
    document.dispatchEvent(new CustomEvent('icons:refresh'));
  }
}
apply(getInitial());
btn?.addEventListener('click', () => {
  apply(html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
});
