// Quando tiver backend real, mude USE_MOCK para false e ajuste API_BASE.
export const USE_MOCK = true; // ⇦ hoje é mock
export const API_BASE = 'http://localhost:8080';