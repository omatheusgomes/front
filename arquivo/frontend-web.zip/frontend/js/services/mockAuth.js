export async function mockLogin({ username, password }) {
  await delay(250); // simula latência
  if (!username || !password) {
    const err = new Error('Usuário e senha são obrigatórios.');
    err.status = 400;
    throw err;
  }
  return {
    token: `mock-${Math.random().toString(36).slice(2)}`,
    user: { id: 1, name: username, role: 'agent' }
  };
}

function delay(ms){ return new Promise(r => setTimeout(r, ms)); }

