import { USE_MOCK, API_BASE } from '../config.js';
import { mockLogin } from './mockAuth.js';

export async function login({ username, password }) {
  if (USE_MOCK) {
    return mockLogin({ username, password });
  }
  // Implementação real quando existir backend
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) {
    const err = new Error('Falha no login');
    err.status = res.status;
    try { err.details = await res.json(); } catch {}
    throw err;
  }
  return res.json(); // { token, user }
}

export function saveSession({ token, user }) {
  localStorage.setItem('nexhelp_auth', JSON.stringify({ token, user }));
}
export function getSession() {
  const raw = localStorage.getItem('nexhelp_auth');
  return raw ? JSON.parse(raw) : null;
}
export function clearSession() {
  localStorage.removeItem('nexhelp_auth');
}
