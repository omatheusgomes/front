/* Relatórios — filtros + tabela + exportação XLSX (minimal OpenXML) */

const els = {
  contato:  document.getElementById('fContato'),
  fila:     document.getElementById('fFila'),
  usuario:  document.getElementById('fUsuario'),
  inicio:   document.getElementById('fInicio'),
  fim:      document.getElementById('fFim'),
  form:     document.getElementById('filtersForm'),
  table:    document.getElementById('reportsTable').querySelector('tbody'),
  count:    document.getElementById('resCount'),
  export:   document.getElementById('btnExport'),
};

const TZ = 'America/Sao_Paulo';
const fmtDateTime = (d)=> new Intl.DateTimeFormat('pt-BR',{
  timeZone:TZ, year:'numeric', month:'2-digit', day:'2-digit',
  hour:'2-digit', minute:'2-digit'
}).format(d);

const dayStart = (d)=> new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0,0,0);
const dayEnd   = (d)=> new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23,59,59);

/* ======== Dados de exemplo (mock) ======== */
const sample = [
  {id:3041, fila:'Suporte Técnico', cliente:'Anderson - Revenda', usuario:'Murilo', status:'FECHADO',  abertura:'2025-10-28T18:12:00-03:00', fechamento:'2025-10-28T20:09:00-03:00'},
  {id:3150, fila:'Suporte Técnico', cliente:'Henrique',            usuario:'Murilo', status:'FECHADO',  abertura:'2025-10-25T10:41:00-03:00', fechamento:'2025-10-25T11:05:00-03:00'},
  {id:3147, fila:'Suporte Técnico', cliente:'Matuto',              usuario:'Murilo', status:'ABERTO',   abertura:'2025-10-24T09:30:00-03:00', fechamento:null},
  {id:3145, fila:'Suporte Técnico', cliente:'Lucas',               usuario:'Murilo', status:'FECHADO',  abertura:'2025-10-24T13:10:00-03:00', fechamento:'2025-10-24T13:55:00-03:00'},
  {id:3144, fila:'Suporte Técnico', cliente:'Alê',                 usuario:'Murilo', status:'FECHADO',  abertura:'2025-10-24T15:12:00-03:00', fechamento:'2025-10-24T16:03:00-03:00'},
  {id:3139, fila:'Suporte Técnico', cliente:'Claudermir',          usuario:'Matheus',status:'FECHADO',  abertura:'2025-10-22T08:20:00-03:00', fechamento:'2025-10-22T10:02:00-03:00'},
  {id:3137, fila:'Suporte Técnico', cliente:'René Lanches',        usuario:'Matheus',status:'FECHADO',  abertura:'2025-10-22T11:10:00-03:00', fechamento:'2025-10-22T11:50:00-03:00'},
  {id:3136, fila:'Suporte Técnico', cliente:'René Lanches',        usuario:'Matheus',status:'FECHADO',  abertura:'2025-10-22T13:44:00-03:00', fechamento:'2025-10-22T14:20:00-03:00'},
  {id:3131, fila:'Suporte Técnico', cliente:'Victor - VIP',        usuario:'Matheus',status:'FECHADO',  abertura:'2025-10-21T17:40:00-03:00', fechamento:'2025-10-21T18:15:00-03:00'},
  {id:3126, fila:'Suporte Técnico', cliente:'Fabinho Açaí',        usuario:'Jonathan',status:'FECHADO', abertura:'2025-10-20T09:00:00-03:00', fechamento:'2025-10-20T10:01:00-03:00'},
];

function unique(list, key){ return [...new Set(list.map(x=>x[key]))].sort((a,b)=> String(a).localeCompare(String(b),'pt-BR')); }
function pad(n){ return String(n).padStart(2,'0'); }
function humanDuration(ms){
  if (ms == null) return '—';
  const m = Math.max(0, Math.round(ms/60000));
  const d = Math.floor(m / (60*24));
  const h = Math.floor((m - d*60*24) / 60);
  const mm= m - d*60*24 - h*60;
  const parts = [];
  if (d) parts.push(`${d} d`);
  parts.push(`${pad(h)}h ${pad(mm)}m`);
  return parts.join(', ');
}

/* popula selects */
function seedFilters(){
  for(const f of unique(sample,'fila'))   els.fila.insertAdjacentHTML('beforeend', `<option>${f}</option>`);
  for(const u of unique(sample,'usuario'))els.usuario.insertAdjacentHTML('beforeend', `<option>${u}</option>`);
  // datas default: últimos 7 dias
  const now=new Date();
  const ini=new Date(now); ini.setDate(now.getDate()-7);
  els.inicio.value = `${ini.getFullYear()}-${pad(ini.getMonth()+1)}-${pad(ini.getDate())}`;
  els.fim.value    = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
}
seedFilters();

/* aplica filtros e renderiza tabela */
function applyFilters(e){
  if (e) e.preventDefault();
  const q    = els.contato.value.trim().toLowerCase();
  const fila = els.fila.value;
  const usr  = els.usuario.value;
  const dIni = els.inicio.value ? dayStart(new Date(els.inicio.value)) : null;
  const dFim = els.fim.value    ? dayEnd(new Date(els.fim.value))     : null;

  const rows = sample.filter(r=>{
    if (q && !`${r.cliente}`.toLowerCase().includes(q)) return false;
    if (fila && r.fila!==fila) return false;
    if (usr && r.usuario!==usr) return false;
    const ab = new Date(r.abertura);
    if (dIni && ab < dIni) return false;
    if (dFim && ab > dFim) return false;
    return true;
  });

  renderTable(rows);
  currentRows = rows;
}
els.form.addEventListener('submit', applyFilters);
['input','change'].forEach(ev=>{
  els.contato.addEventListener(ev, (e)=>{ if (ev==='change') applyFilters(); });
  els.fila.addEventListener(ev, applyFilters);
  els.usuario.addEventListener(ev, applyFilters);
  els.inicio.addEventListener(ev, applyFilters);
  els.fim.addEventListener(ev, applyFilters);
});

/* tabela */
function renderTable(rows){
  els.table.innerHTML='';
  for(const r of rows){
    const ab = new Date(r.abertura);
    const fe = r.fechamento? new Date(r.fechamento): null;
    const dur = fe? (fe-ab): null;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>#${r.id}</td>
      <td>${r.fila}</td>
      <td title="${r.cliente}">${r.cliente}</td>
      <td>${r.usuario}</td>
      <td>${r.status}</td>
      <td>${fmtDateTime(ab)}</td>
      <td>${fe? fmtDateTime(fe) : '—'}</td>
      <td>${humanDuration(dur)}</td>
    `;
    els.table.appendChild(tr);
  }
  els.count.textContent = rows.length;
}
let currentRows = [];
applyFilters();

/* ======== Exportação XLSX (OpenXML minimal, sem dependências) ======== */
function xmlEscape(s){return String(s).replace(/[<>&'"]/g,m=>({ '<':'&lt;','>':'&gt;','&':'&amp;',"'":'&apos;','"':'&quot;' }[m]));}
function colName(n){ // 1->A
  let s='', a=n;
  while(a>0){ const m=(a-1)%26; s=String.fromCharCode(65+m)+s; a=Math.floor((a-1)/26); }
  return s;
}
function sheetXML(rows){
  let out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
    '<sheetData>'];

  rows.forEach((row,rIdx)=>{
    out.push(`<row r="${rIdx+1}">`);
    row.forEach((cell,cIdx)=>{
      const r = `${colName(cIdx+1)}${rIdx+1}`;
      if (cell==null){ out.push(`<c r="${r}"/>`); return; }
      const v = String(cell);
      // tudo como inlineStr p/ simplicidade
      out.push(`<c r="${r}" t="inlineStr"><is><t>${xmlEscape(v)}</t></is></c>`);
    });
    out.push('</row>');
  });
  out.push('</sheetData></worksheet>');
  return out.join('');
}
function workbookXML(){
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
      <sheet name="Relatório" sheetId="1" r:id="rId1"/>
    </sheets>
  </workbook>`;
}
function rels_root(){return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  </Relationships>`;}
function rels_wb(){return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <Relationships xmlns="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  </Relationships>`;}
function contentTypes(){return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="xml" ContentType="application/xml"/>
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  </Types>`;}

/* ZIP (store) bem enxuto */
const CRC_TABLE = (()=>{ let c, t=new Uint32Array(256); for(let n=0;n<256;n++){ c=n; for(let k=0;k<8;k++) c = (c&1)? (0xEDB88320^(c>>>1)) : (c>>>1); t[n]=c>>>0; } return t;})();
function crc32(u8){ let c=~0; for(let i=0;i<u8.length;i++) c = CRC_TABLE[(c^u8[i])&0xFF] ^ (c>>>8); return (~c)>>>0; }
function strU8(s){ return new TextEncoder().encode(s); }

function zipStore(files){ // [{name, u8}]
  const hdrs=[]; const cd=[]; let offset=0;
  const push32 = (arr, n)=>{ arr.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255); };
  const push16 = (arr, n)=>{ arr.push(n&255,(n>>>8)&255); };

  const out = [];
  for(const f of files){
    const nameU8 = strU8(f.name);
    const data = f.u8;
    const crc  = crc32(data);
    const comp = 0; // store
    const dosTime=0, dosDate=0;

    const lh=[]; // local header
    push32(lh,0x04034b50); push16(lh,20); push16(lh,0); push16(lh,comp);
    push16(lh,dosTime); push16(lh,dosDate); push32(lh,crc); push32(lh,data.length); push32(lh,data.length);
    push16(lh,nameU8.length); push16(lh,0);
    out.push(...lh, ...nameU8, ...data);
    const localOffset = offset;
    offset += lh.length + nameU8.length + data.length;

    const ch=[]; // central directory header
    push32(ch,0x02014b50); push16(ch,20); push16(ch,20); push16(ch,0); push16(ch,comp);
    push16(ch,dosTime); push16(ch,dosDate); push32(ch,crc); push32(ch,data.length); push32(ch,data.length);
    push16(ch,nameU8.length); push16(ch,0); push16(ch,0); push16(ch,0); push16(ch,0); push32(ch,0);
    push32(ch,localOffset);
    cd.push(...ch,...nameU8);
  }
  const eocd=[]; // end of central directory
  push32(eocd,0x06054b50); push16(eocd,0); push16(eocd,0);
  push16(eocd,files.length); push16(eocd,files.length);
  push32(eocd,cd.length); push32(eocd,offset);
  push16(eocd,0);

  const all = new Uint8Array(out.length + cd.length + eocd.length);
  all.set(out,0); all.set(cd,out.length); all.set(eocd, out.length+cd.length);
  return all;
}

function downloadXLSX(rows){
  const header = ['Ticket','Fila','Cliente','Usuário','Status','Data Abertura','Data Fechamento','Tempo de Atendimento'];
  const xmlSheet = sheetXML([header, ...rows]);
  const files = [
    {name:'[Content_Types].xml',            u8:strU8(contentTypes())},
    {name:'_rels/.rels',                    u8:strU8(rels_root())},
    {name:'xl/workbook.xml',                u8:strU8(workbookXML())},
    {name:'xl/_rels/workbook.xml.rels',     u8:strU8(rels_wb())},
    {name:'xl/worksheets/sheet1.xml',       u8:strU8(xmlSheet)},
  ];
  const zip = zipStore(files);
  const blob = new Blob([zip], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  const a = document.createElement('a');
  const today = new Date();
  const y=today.getFullYear(), m=String(today.getMonth()+1).padStart(2,'0'), d=String(today.getDate()).padStart(2,'0');
  a.download = `relatorio_chamados_${y}-${m}-${d}.xlsx`;
  a.href = URL.createObjectURL(blob);
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href), 2000);
}

/* clique Exportar */
els.export.addEventListener('click', ()=>{
  const mapped = currentRows.map(r=>{
    const ab = new Date(r.abertura);
    const fe = r.fechamento? new Date(r.fechamento): null;
    const dur = fe? (fe-ab): null;
    return [
      `#${r.id}`, r.fila, r.cliente, r.usuario, r.status,
      fmtDateTime(ab), fe? fmtDateTime(fe) : '—', humanDuration(dur)
    ];
  });
  downloadXLSX(mapped);
});

/* tema (opcional, se já existir no projeto pode ignorar) */
document.getElementById('themeSwitch')?.addEventListener('click', ()=>{
  const root = document.documentElement;
  const cur = root.getAttribute('data-theme')==='dark' ? 'light':'dark';
  root.setAttribute('data-theme', cur);
});
