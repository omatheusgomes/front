// js/chamados.js
const els = {
  // abas / listas
  subtabs: document.querySelector('.subtabs'),
  subtabsUnderline: document.getElementById('subtabsUnderline'),
  listAtendendo: document.getElementById('list-atendendo'),
  listAguardando: document.getElementById('list-aguardando'),
  listFinalizados: document.getElementById('list-finalizados'),

  // chat
  chatBody: document.getElementById('chatBody'),
  chatEmpty: document.getElementById('chatEmpty'),

  // header
  chatBackBtn: document.getElementById('chatBackBtn'),
  chatTitle: document.getElementById('chatTitle'),
  chatId: document.getElementById('chatId'),
  chatMeta: document.getElementById('chatMeta'),

  finishBtn: document.getElementById('finishBtn'),
  returnBtn: document.getElementById('returnBtn'),
  reopenBtn: document.getElementById('reopenBtn'),
  transferBtn: document.getElementById('transferBtn'),
  botToggle: document.getElementById('botToggle'),
  moreBtn: document.getElementById('moreBtn'),
  moreMenu: document.getElementById('moreMenu'),
  deleteChatBtn: document.getElementById('deleteChatBtn'),
  exportPdfBtn: document.getElementById('exportPdfBtn'),

  // TAGS (barra abaixo do header)
  chatTagsBar: document.getElementById('chatTagsBar'),
  chatTagsMenu: document.getElementById('chatTagsMenu'),
  appliedTags: document.getElementById('appliedTags'),
  tagsOptions: document.getElementById('tagsOptions'),
  tagsSearch: document.getElementById('tagsSearch'),

  // modal Transferir
  transferDialog: document.getElementById('transferDialog'),
  transferForm: document.getElementById('transferForm'),
  transferQueue: document.getElementById('transferQueue'),
  transferUser: document.getElementById('transferUser'),
  transferCancel: document.getElementById('transferCancel'),
  transferConfirm: document.getElementById('transferConfirm'),

  // composer
  composerInput: document.getElementById('composerInput'),
  composerSend: document.getElementById('composerSend'),
  emojiBtn: document.getElementById('emojiBtn'),
  emojiPanel: document.getElementById('emojiPanel'),
  attachBtn: document.getElementById('attachBtn'),
  attachMenu: document.getElementById('attachMenu'),
  pickImages: document.getElementById('pickImages'),
  pickFiles: document.getElementById('pickFiles'),
  audioBtn: document.getElementById('audioBtn'),

  // perfil / logout
  profileBtn: document.getElementById('profileBtn'),
  profileMenu: document.getElementById('profileMenu'),
  myProfileBtn: document.getElementById('myProfileBtn'),
  logoutBtn: document.getElementById('logoutBtn'),

  // logout modal
  logoutDialog: document.getElementById('logoutDialog'),
  logoutConfirm: document.getElementById('logoutConfirm'),
  logoutCancel: document.getElementById('logoutCancel'),

  // lightbox
  lb: document.getElementById('imgLightbox'),
  lbImg: document.getElementById('lbImg'),
};
const layoutCols = document.querySelector('.two-cols');
const root = document.documentElement;

/* Largura da lista — um pouco maior que o original, mas sem exagero */
root.style.setProperty('--inbox-w', '30rem');

/* Papel de parede estático do chat */
(function fixChatBackground() {
  if (!els.chatBody) return;
  els.chatBody.style.backgroundAttachment = 'fixed';
  els.chatBody.style.backgroundPosition = 'center';
  els.chatBody.style.backgroundSize = 'cover';
})();

const TZ = 'America/Sao_Paulo';
const clock = (ts) =>
  new Intl.DateTimeFormat('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: TZ
  }).format(ts ?? Date.now());

/* ==== STATE ==== */
const state = {
  currentTab: 'atendendo',
  currentChatId: null,
  currentChatListName: null,

  // opções para modal Transferir (carregadas de configurações)
  queues: [],
  users: ['Matheus', 'Ana', 'Pedro'],

  // catálogo de tags (carregado do localStorage se houver)
  tagsCatalog: [],

  // listas
  chats: {
    atendendo: [],
    aguardando: [],
    finalizados: []
  }
};

/* ==== Storage helpers ==== */
function loadTagsCatalog() {
  try {
    const raw = localStorage.getItem('nexhelp_tags');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map(t => ({
        id: String(t.id ?? t.name ?? crypto.randomUUID()),
        name: String(t.name ?? 'TAG'),
        color: String(t.color ?? '#22c55e')
      }));
    }
  } catch {}
  return [
    { id: 'completo',   name: 'COMPLETO',   color: '#22c55e' },
    { id: 'prioridade', name: 'PRIORIDADE', color: '#f59e0b' },
    { id: 'financeiro', name: 'FINANCEIRO', color: '#3b82f6' },
  ];
}
state.tagsCatalog = loadTagsCatalog();

// Carrega filas e categorias de configurações
function loadQueuesFromConfig() {
  try {
    const raw = localStorage.getItem('nexhelp_queues');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(q => q.active).map(q => q.name);
      }
    }
  } catch {}
  return ['Suporte', 'Financeiro', 'Comercial']; // fallback
}
state.queues = loadQueuesFromConfig();

/* ==== Seed: 1 chamado visível na lista ==== */
(function seed(){
  state.chats.atendendo = [{
    id: 1027,
    title: 'Maria Silva',
    last: 'Bom dia! Estou com dúvida na fatura.',
    lastAt: Date.now(),
    assigned: 'Matheus',
    fila: 'Suporte',
    bot: true,
    tags: []
  }];

  state.chats.aguardando = [{
    id: 2051,
    title: 'Esquina do Açaí',
    last: 'Consegue me ajudar com o boleto?',
    lastAt: Date.now() - 5 * 60 * 1000,
    assigned: '—',
    fila: 'Suporte',
    bot: false,
    tags: []
  }];
  state.chats.finalizados = [];
})();

/* ==== Utils ==== */
function esc(s){
  return String(s).replace(/[&<>"']/g, m => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  })[m]);
}
function getList(name){
  if (name==='atendendo') return state.chats.atendendo;
  if (name==='aguardando') return state.chats.aguardando;
  return state.chats.finalizados;
}
function chatById(id){
  for (const k of ['atendendo','aguardando','finalizados']){
    const i = getList(k).findIndex(r=>r.id===id);
    if (i>-1) return { list:k, index:i, row:getList(k)[i] };
  }
  return null;
}

/* == ÁUDIO: helpers e estado == */
function formatClock(msOrSec){
  const totalMs = msOrSec > 1000 ? Math.round(msOrSec) : Math.round(msOrSec * 1000);
  const s = Math.max(0, Math.floor(totalMs / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2,'0')}`;
}

let mediaStream = null;
let mediaRecorder = null;
let recChunks = [];
let isRecording = false;

const audioPlayers = new Set();
function pauseOthers(except){
  audioPlayers.forEach(a => { if (a !== except && !a.paused) a.pause(); });
}
function swapIcon(iconEl, name){
  if (!iconEl) return;
  iconEl.setAttribute('data-icon', name);
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}

/* ==== Subtabs underline animada ==== */
function moveUnderline(){
  const act = els.subtabs?.querySelector('.subtab.is-active');
  if (!act || !els.subtabsUnderline) return;
  const w = act.offsetWidth;
  const x = act.offsetLeft;
  els.subtabsUnderline.style.width = `${w}px`;
  els.subtabsUnderline.style.transform = `translateX(${x}px)`;
}
window.addEventListener('resize', moveUnderline);

/* ==== Render das listas ==== */
function makeItem(row, listName){
  const li = document.createElement('li');
  li.className = 'conv-item';
  li.dataset.chatId = row.id;

  let actions = '';
  if (listName === 'atendendo') {
    actions = `
      <button class="icon-btn ghost success" data-action="finish" title="Finalizar">
        <span class="icon" data-icon="circle-check"></span>
      </button>
      <button class="icon-btn ghost" data-action="transfer" title="Transferir">
        <span class="icon" data-icon="arrow-right-left"></span>
      </button>`;
  } else if (listName === 'aguardando') {
    actions = `
      <button class="icon-btn ghost success" data-action="accept" title="Aceitar (ir para Atendendo)">
        <span class="icon" data-icon="circle-check"></span>
      </button>
      <button class="icon-btn ghost" data-action="ignore" title="Ignorar (resolver)">
        <span class="icon" data-icon="circle-x"></span>
      </button>`;
  } else {
    actions = ``;
  }

  li.innerHTML = `
    <span class="conv-avatar icon" data-icon="book-user"></span>
    <div class="conv-main">
      <div class="conv-top">
        <strong class="conv-name">${esc(row.title)}</strong>
        <span class="conv-time" data-ts="${row.lastAt}">${clock(row.lastAt)}</span>
      </div>
      <div class="conv-preview" title="${esc(row.last)}">${esc(row.last)}</div>
      <div class="conv-meta">
        <span class="conv-chip">${esc(row.assigned)} — ${esc(row.fila)}</span>
      </div>
    </div>
    <div class="conv-actions">${actions}</div>`;
  return li;
}
function renderLists(){
  els.listAtendendo.innerHTML = '';
  els.listAguardando.innerHTML = '';
  els.listFinalizados.innerHTML = '';
  state.chats.atendendo.forEach(r=>els.listAtendendo.appendChild(makeItem(r,'atendendo')));
  state.chats.aguardando.forEach(r=>els.listAguardando.appendChild(makeItem(r,'aguardando')));
  state.chats.finalizados.forEach(r=>els.listFinalizados.appendChild(makeItem(r,'finalizados')));
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}
renderLists();

/* relógio da lista */
setInterval(()=>{
  document.querySelectorAll('.conv-time').forEach(el=>{
    const ts = Number(el.getAttribute('data-ts')) || Date.now();
    el.textContent = clock(ts);
  });
}, 60*1000);

/* troca de subtab */
els.subtabs?.addEventListener('click', (e)=>{
  const b = e.target.closest('.subtab'); if (!b) return;
  els.subtabs.querySelectorAll('.subtab').forEach(x=>x.classList.remove('is-active'));
  b.classList.add('is-active');
  state.currentTab = b.dataset.subtab;

  els.listAtendendo.hidden   = state.currentTab !== 'atendendo';
  els.listAguardando.hidden  = state.currentTab !== 'aguardando';
  els.listFinalizados.hidden = state.currentTab !== 'finalizados';

  moveUnderline();
});
moveUnderline();

/* ==== Composer helpers ==== */
function setComposerEnabled(on){
  els.composerInput.disabled = !on;
  els.composerSend.disabled = !on || !els.composerInput.value.trim();
  updateComposerButtons();
  if (on) els.composerInput.focus();
}
function updateComposerButtons(){
  const hasText = !!els.composerInput.value.trim() && !els.composerInput.disabled;
  if (els.audioBtn)  els.audioBtn.hidden  = hasText;
  if (els.composerSend) els.composerSend.hidden = !hasText;
  const composer = document.querySelector('.chat-composer');
  if (composer) composer.classList.toggle('typing', hasText);
}

/* Estado vazio (sem chat aberto) */
function setChatEmpty(isEmpty){
  const chatEl = document.querySelector('.chat');
  const chatHeader = document.querySelector('.chat-header');
  const chatComposer = document.querySelector('.chat-composer');

  chatEl.classList.toggle('is-empty', !!isEmpty);
  chatEl.style.gridTemplateRows = isEmpty ? '1fr' : 'auto auto 1fr auto'; // header + tags + body + composer

  if (chatHeader)   chatHeader.style.display  = isEmpty ? 'none' : '';
  const tagsBarWrap = document.getElementById('chatTags');
  if (tagsBarWrap)  tagsBarWrap.style.display = isEmpty ? 'none' : '';
  if (chatComposer) chatComposer.style.display = isEmpty ? 'none' : '';

  if (els.chatEmpty) els.chatEmpty.hidden = !isEmpty;

  if (isEmpty) layoutCols?.classList.add('only-inbox');
  else         layoutCols?.classList.remove('only-inbox');

  setComposerEnabled(!isEmpty && state.currentChatListName!=='finalizados');
}

/* ==== Lista: ações e abrir chat ==== */
document.querySelector('.inbox')?.addEventListener('click', (e)=>{
  const actionBtn = e.target.closest('.conv-actions .icon-btn');
  if (actionBtn){
    e.stopPropagation();
    const li = actionBtn.closest('.conv-item'); if (!li) return;
    const id = Number(li.dataset.chatId);
    const found = chatById(id); if (!found) return;

    if (actionBtn.dataset.action === 'finish'){
      if (found.list!=='finalizados'){
        getList(found.list).splice(found.index,1);
        state.chats.finalizados.unshift(found.row);
        renderLists();
        if (state.currentChatId===id) openChat(found.row, 'finalizados');
      }
      return;
    }
    if (actionBtn.dataset.action === 'transfer'){
      openChat(found.row, found.list);
      openTransferModal();
      return;
    }
    if (actionBtn.dataset.action === 'accept'){
      if (found.list==='aguardando'){
        getList(found.list).splice(found.index,1);
        state.chats.atendendo.unshift(found.row);
        renderLists();
        openChat(found.row, 'atendendo');
      }
      return;
    }
    if (actionBtn.dataset.action === 'ignore'){
      if (found.list==='aguardando'){
        getList(found.list).splice(found.index,1);
        state.chats.finalizados.unshift(found.row);
        renderLists();
        openChat(found.row, 'finalizados');
      }
      return;
    }
  }

  const li = e.target.closest('.conv-item'); if (!li) return;
  document.querySelectorAll('.conv-item').forEach(x=>x.classList.remove('is-active'));
  li.classList.add('is-active');
  const id = Number(li.dataset.chatId);

  const found = chatById(id);
  if (!found) return;
  openChat(found.row, found.list);
});

/* ==== Header helpers ==== */
function setHeaderEmpty(){
  els.chatTitle.textContent = '';
  els.chatId.textContent = '—';
  els.chatMeta.textContent = '—';
  setComposerEnabled(false);
  els.composerInput.placeholder = 'Escreva uma mensagem…';
  if (els.appliedTags) els.appliedTags.innerHTML = '';
}
function openChat(row, listName){
  document.querySelectorAll('.conv-item').forEach(x=>x.classList.remove('is-active'));
  const li = document.querySelector(`.conv-item[data-chat-id="${row.id}"]`); if (li) li.classList.add('is-active');

  layoutCols?.classList.remove('only-inbox');
  state.currentChatId = row.id;
  state.currentChatListName = listName;

  els.chatTitle.textContent = row.title;
  els.chatId.textContent = `#${row.id}`;
  els.chatMeta.textContent = `Atribuído a ${row.assigned} • ${row.fila}`;
  els.botToggle.checked = !!row.bot;

  const isFinalizado = (listName==='finalizados');
  if (els.finishBtn) els.finishBtn.hidden = isFinalizado;
  if (els.returnBtn) els.returnBtn.hidden = isFinalizado;
  if (els.reopenBtn) els.reopenBtn.hidden = !isFinalizado;

  setComposerEnabled(!isFinalizado);
  els.composerInput.placeholder = isFinalizado ? 'Chamado finalizado' : 'Escreva uma mensagem…';

  els.chatBody.innerHTML = '';
  els.chatBody.appendChild(els.chatEmpty);
  setChatEmpty(false);

  renderAppliedTags();

  addMsg({ me:false, text:'Mensagem do cliente…', date:Date.now()-120000, status:'received' });
  addMsg({ me:true,  text:'Olá! Estou verificando seu chamado.', date:Date.now()-60000, status:'sent' });
}

/* atualiza prévia da conversa (última mensagem) */
function updatePreviewForCurrentChat(previewText){
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  found.row.last = previewText;
  found.row.lastAt = Date.now();
  renderLists();
}

/* ==== Mensagens ==== */
function addMsg(m){
  const t = m.date ?? Date.now();
  const el = document.createElement('div');
  el.className = `msg ${m.me ? 'msg-out' : 'msg-in'}`;

  if (m.type==='image') {
    el.innerHTML = `
      <div class="msg-bubble media">
        <img class="msg-image" src="${esc(m.src)}" alt="Imagem" />
        <span class="msg-time">${clock(t)}</span>
        <div class="msg-status ${m.status==='read' ? 'read': ''}">
          <span class="icon" data-icon="${m.status==='read' ? 'checks' : (m.status==='received' ? 'checks' : 'check')}"></span>
        </div>
      </div>`;
    if (m.me) updatePreviewForCurrentChat('📷 Imagem');
  } else if (m.type === 'audio') {
    const totalLabel = m.durationMs ? formatClock(m.durationMs) : '0:00';
    el.innerHTML = `
      <div class="msg-bubble audio">
        <div class="msg-audio">
          <button class="audio-play" type="button" title="Reproduzir">
            <span class="icon" data-icon="play"></span>
          </button>
          <div class="audio-bar"><div class="audio-progress" style="width:0%"></div></div>
          <div class="audio-time"><span class="t-elapsed">0:00</span> <span class="sep">/</span> <span class="t-total">${totalLabel}</span></div>
        </div>
        <span class="msg-time">${clock(t)}</span>
        ${m.me ? `<div class="msg-status ${m.status==='read' ? 'read': ''}">
          <span class="icon" data-icon="${m.status==='read' ? 'checks' : (m.status==='received' ? 'checks' : 'check')}"></span>
        </div>`:''}
      </div>`;

    const audio = new Audio(m.src);
    audio.preload = 'metadata';
    audioPlayers.add(audio);

    const bubble = el.querySelector('.msg-bubble.audio');
    const btn = bubble.querySelector('.audio-play');
    const btnIcon = btn.querySelector('.icon');
    const bar = bubble.querySelector('.audio-bar');
    const prog = bubble.querySelector('.audio-progress');
    const tElapsed = bubble.querySelector('.t-elapsed');
    const tTotal = bubble.querySelector('.t-total');

    // Inicializa tempo total imediatamente se disponível
    if (m.durationMs && m.durationMs > 0) {
      tTotal.textContent = formatClock(m.durationMs);
    }

    const playPause = () => {
      if (audio.paused) { pauseOthers(audio); audio.play(); }
      else { audio.pause(); }
    };
    btn.addEventListener('click', playPause);

    let metadataLoaded = false;
    audio.addEventListener('loadedmetadata', ()=>{
      if (!isFinite(audio.duration) || metadataLoaded) return;
      metadataLoaded = true;
      const realDuration = audio.duration * 1000;
      tTotal.textContent = formatClock(realDuration);
      if (m.me) updatePreviewForCurrentChat(`🎧 Áudio (${tTotal.textContent})`);
    });

    audio.addEventListener('play', ()=> swapIcon(btnIcon, 'pause'));
    audio.addEventListener('pause', ()=> swapIcon(btnIcon, 'play'));
    audio.addEventListener('ended', ()=>{
      prog.style.width = '100%';
      if (metadataLoaded && isFinite(audio.duration)) {
        tElapsed.textContent = formatClock(audio.duration * 1000);
      } else if (m.durationMs) {
        tElapsed.textContent = formatClock(m.durationMs);
      }
      swapIcon(btnIcon, 'play');
    });
    
    let lastUpdate = 0;
    audio.addEventListener('timeupdate', ()=>{
      if (!metadataLoaded || !isFinite(audio.duration)) return;
      const now = Date.now();
      if (now - lastUpdate < 100) return; // Throttle para evitar updates muito frequentes
      lastUpdate = now;
      const p = (audio.currentTime / audio.duration) * 100;
      prog.style.width = `${p}%`;
      tElapsed.textContent = formatClock(audio.currentTime * 1000);
    });

    bar.addEventListener('click', (ev)=>{
      if (!metadataLoaded || !isFinite(audio.duration)) return;
      const r = bar.getBoundingClientRect();
      const pct = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
      audio.currentTime = pct * audio.duration;
    });

  } else {
    el.innerHTML = `
      <div class="msg-bubble">
        ${esc(m.text)}
        <span class="msg-time">${clock(t)}</span>
        ${m.me ? `<div class="msg-status ${m.status==='read' ? 'read': ''}">
          <span class="icon" data-icon="${m.status==='read' ? 'checks' : (m.status==='received' ? 'checks' : 'check')}"></span>
        </div>`:''}
      </div>`;
    if (m.me) updatePreviewForCurrentChat(m.text);
  }

  els.chatBody.appendChild(el);
  els.chatBody.scrollTop = els.chatBody.scrollHeight;
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}

/* ==== Composer ==== */
els.composerInput?.addEventListener('input', ()=>{
  els.composerSend.disabled = !els.composerInput.value.trim() || els.composerInput.disabled;
  updateComposerButtons();
});
els.composerInput?.addEventListener('keydown', (ev)=>{
  if (ev.key==='Enter' && !ev.shiftKey){
    ev.preventDefault();
    if (!els.composerSend.hidden) els.composerSend.click();
  }
});
els.composerSend?.addEventListener('click', async ()=>{
  const t = els.composerInput.value.trim(); if (!t) return;
  addMsg({ me:true, text:t, date:Date.now(), status:'sent' });
  els.composerInput.value = '';
  els.composerSend.disabled = true;
  updateComposerButtons();

  // Se bot está ativado, gera resposta automática via OpenAI
  if (state.currentChatId && els.botToggle?.checked) {
    await generateAIResponse(t);
  }
});
document.querySelector('.chat-composer')?.addEventListener('click', (e)=>{
  if (e.target.closest('button, .attach-menu, .emoji-popover')) return;
  if (!els.composerInput.disabled) els.composerInput.focus();
});

/* ==== EMOJI ==== */
let emojiReady = false;
async function ensureEmojiPicker(){
  if (emojiReady) return;
  await import('https://cdn.jsdelivr.net/npm/emoji-picker-element/+esm');
  const picker = document.createElement('emoji-picker');
  picker.setAttribute('emoji-version','14.0');
  picker.style.inlineSize='100%';
  picker.style.blockSize='100%';
  picker.addEventListener('emoji-click', (ev)=>{
    const emoji = ev.detail.unicode || ev.detail.emoji;
    const el = els.composerInput;
    const pos = el.selectionStart ?? el.value.length;
    el.value = el.value.slice(0,pos) + emoji + el.value.slice(pos);
    el.focus();
    els.composerSend.disabled = !el.value.trim();
    updateComposerButtons();
  });
  els.emojiPanel.appendChild(picker);
  emojiReady=true;
}
function toggleEmoji(open){
  const willOpen = open ?? els.emojiPanel.hasAttribute('hidden');
  els.emojiPanel.toggleAttribute('hidden', !willOpen);
  if (willOpen){
    ensureEmojiPicker();
    setTimeout(()=>{
      const closer=(e)=>{
        if (!els.emojiPanel.contains(e.target) && e.target!==els.emojiBtn){
          els.emojiPanel.hidden = true; document.removeEventListener('click', closer);
        }
      };
      document.addEventListener('click', closer);
    }, 0);
  }
}
els.emojiBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); toggleEmoji(); });

/* ==== ANEXOS ==== */
function toggleAttachMenu(open){
  const willOpen = open ?? els.attachMenu.hasAttribute('hidden');
  els.attachMenu.toggleAttribute('hidden', !willOpen);
  els.attachBtn?.setAttribute('aria-expanded', String(willOpen));
  if (willOpen){
    setTimeout(()=>{
      const closer=(e)=>{
        if(!els.attachMenu.contains(e.target) && e.target!==els.attachBtn){
          els.attachMenu.hidden = true; document.removeEventListener('click', closer);
        }
      };
      document.addEventListener('click', closer);
    },0);
  }
}
els.attachBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); toggleAttachMenu(); });

els.attachMenu?.addEventListener('click', (e)=>{
  const item = e.target.closest('.attach-item'); if (!item) return;
  els.attachMenu.hidden = true;
  if (item.dataset.kind==='image') els.pickImages?.click();
  if (item.dataset.kind==='file')  els.pickFiles?.click();
});

els.pickImages?.addEventListener('change', ()=>{
  const files = [...(els.pickImages.files||[])];
  files.forEach(f=>{
    const url = URL.createObjectURL(f);
    addMsg({ me:true, type:'image', src:url, status:'sent', date:Date.now() });
  });
  els.pickImages.value='';
});
els.pickFiles?.addEventListener('change', ()=>{
  const files = [...(els.pickFiles.files||[])];
  if (files.length){
    files.forEach(f=>{
      addMsg({ me:true, text:`📎 ${f.name}`, status:'sent', date:Date.now() });
    });
  }
  els.pickFiles.value='';
});

/* ==== Lightbox imagens ==== */
els.chatBody.addEventListener('click', (e)=>{
  const img = e.target.closest('.msg-image'); if (!img) return;
  els.lbImg.src = img.src;
  els.lb.hidden = false;
});
els.lb?.addEventListener('click', ()=>{ els.lb.hidden = true; els.lbImg.src=''; });

/* ==== BOTÕES DO HEADER ==== */
els.chatBackBtn?.addEventListener('click', ()=>{
  state.currentChatId = null; state.currentChatListName = null;
  els.chatBody.innerHTML = '';
  els.chatBody.appendChild(els.chatEmpty);
  setHeaderEmpty();
  setChatEmpty(true);
  document.querySelectorAll('.conv-item').forEach(x=>x.classList.remove('is-active'));
});

els.finishBtn?.addEventListener('click', ()=>{
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  if (found.list==='finalizados') return;
  getList(found.list).splice(found.index,1);
  state.chats.finalizados.unshift(found.row);
  renderLists();
  openChat(found.row, 'finalizados');
});

els.returnBtn?.addEventListener('click', ()=>{
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  if (found.list==='aguardando') return;
  getList(found.list).splice(found.index,1);
  state.chats.aguardando.unshift(found.row);
  renderLists();
  openChat(found.row, 'aguardando');
});

// Reabrir (Finalizados -> Atendendo)
els.reopenBtn?.addEventListener('click', ()=>{
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  if (found.list!=='finalizados') return;
  getList(found.list).splice(found.index,1);
  state.chats.atendendo.unshift(found.row);
  renderLists();
  openChat(found.row, 'atendendo');
});

/* ==== Menus genéricos (perfil / mais) ==== */
function togglePanel(btn, panel){
  const will = panel.hasAttribute('hidden');
  panel.toggleAttribute('hidden', !will);
  if (will){
    setTimeout(()=>{
      const closer=(e)=>{
        if (!panel.contains(e.target) && e.target!==btn){
          panel.hidden = true; document.removeEventListener('click', closer);
        }
      };
      document.addEventListener('click', closer);
    },0);
  }
}
els.moreBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); togglePanel(els.moreBtn, els.moreMenu); });

/* ==== Transferência via MODAL ==== */
function openTransferModal(){
  els.transferQueue.innerHTML = state.queues.map(q=>`<option value="${esc(q)}">${esc(q)}</option>`).join('');
  els.transferUser.innerHTML  = state.users.map(u=>`<option value="${esc(u)}">${esc(u)}</option>`).join('');

  const found = chatById(state.currentChatId);
  if (found){
    els.transferQueue.value = found.row.fila;
    els.transferUser.value = found.row.assigned;
  }

  els.transferDialog.hidden = false;
  els.transferBtn?.setAttribute('aria-expanded','true');
  els.transferCancel?.focus();
}
function closeTransferModal(){
  els.transferDialog.hidden = true;
  els.transferBtn?.setAttribute('aria-expanded','false');
}
els.transferBtn?.addEventListener('click', openTransferModal);
els.transferCancel?.addEventListener('click', closeTransferModal);
els.transferDialog?.addEventListener('click', (e)=>{
  if (e.target.classList.contains('backdrop')) closeTransferModal();
});
els.transferForm?.addEventListener('submit', (e)=>{
  e.preventDefault();
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;

  found.row.fila = els.transferQueue.value;
  found.row.assigned = els.transferUser.value;

  els.chatMeta.textContent = `Atribuído a ${found.row.assigned} • ${found.row.fila}`;
  renderLists();
  closeTransferModal();
});

/* ==== TAGS: catálogo, render, aplicar/remover ==== */
function renderTagsOptions(filter=''){
  if (!els.tagsOptions) return;
  const f = filter.trim().toLowerCase();
  const list = state.tagsCatalog.filter(t => t.name.toLowerCase().includes(f));
  els.tagsOptions.innerHTML = list.map(t => `
    <li>
      <button class="menu-item" role="option" data-tag-id="${esc(t.id)}" title="Aplicar tag">
        <span class="tag-dot" style="inline-size:.7rem; block-size:.7rem; border-radius:999px; margin-right:.5rem; background:${esc(t.color)}"></span>
        ${esc(t.name)}
      </button>
    </li>
  `).join('');
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}
function renderAppliedTags(){
  if (!els.appliedTags) return;
  els.appliedTags.innerHTML = '';
  const found = chatById(state.currentChatId); if (!found) return;
  const currentTags = found.row.tags || [];
  currentTags.forEach(id=>{
    const meta = state.tagsCatalog.find(t=>t.id===id);
    const label = meta?.name ?? id;
    const color = meta?.color ?? '#64748b';
    const el = document.createElement('span');
    el.className = 'tag-badge';
    el.style.background = color + '22';
    el.style.border = `1px solid ${color}55`;
    el.style.color = 'inherit';
    el.style.padding = '.25rem .5rem';
    el.style.borderRadius = '999px';
    el.style.fontSize = '.8rem';
    el.style.fontWeight = '700';
    el.style.display = 'inline-flex';
    el.style.alignItems = 'center';
    el.style.gap = '.4rem';
    el.innerHTML = `${esc(label)} <button class="tag-x" data-remove-tag="${esc(id)}" title="Remover tag" aria-label="Remover tag">✕</button>`;
    els.appliedTags.appendChild(el);
  });
}
function toggleTagsMenu(open){
  const willOpen = open ?? els.chatTagsMenu.hasAttribute('hidden');
  els.chatTagsMenu.toggleAttribute('hidden', !willOpen);
  els.chatTagsBar?.setAttribute('aria-expanded', String(willOpen));
  if (willOpen){
    renderTagsOptions('');
    els.tagsSearch.value = '';
    setTimeout(()=>{
      const closer=(e)=>{
        if (!els.chatTagsMenu.contains(e.target) && e.target!==els.chatTagsBar){
          els.chatTagsMenu.hidden = true; document.removeEventListener('click', closer);
          els.chatTagsBar?.setAttribute('aria-expanded','false');
        }
      };
      document.addEventListener('click', closer);
    },0);
  }
}
els.chatTagsBar?.addEventListener('click', (e)=>{ e.stopPropagation(); toggleTagsMenu(); });
els.tagsSearch?.addEventListener('input', ()=> renderTagsOptions(els.tagsSearch.value||''));
els.tagsOptions?.addEventListener('click', (e)=>{
  const btn = e.target.closest('[data-tag-id]'); if (!btn) return;
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  found.row.tags = found.row.tags || [];
  const id = btn.dataset.tagId;
  if (!found.row.tags.includes(id)) found.row.tags.push(id);
  renderAppliedTags();
});
els.appliedTags?.addEventListener('click', (e)=>{
  const x = e.target.closest('[data-remove-tag]'); if (!x) return;
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  const id = x.dataset.removeTag;
  found.row.tags = (found.row.tags||[]).filter(t=>t!==id);
  renderAppliedTags();
});

/* ==== Perfil (menu) ==== */
els.profileBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); togglePanel(els.profileBtn, els.profileMenu); });
els.myProfileBtn?.addEventListener('click', ()=>{ els.profileMenu.hidden = true; /* placeholder */ });

/* ==== Modal Logout ==== */
function openLogoutModal(){
  els.profileMenu.hidden = true;
  els.logoutDialog.hidden = false;
  els.logoutCancel.focus();
}
function closeLogoutModal(){ els.logoutDialog.hidden = true; }
els.logoutBtn?.addEventListener('click', openLogoutModal);
els.logoutCancel?.addEventListener('click', closeLogoutModal);
els.logoutConfirm?.addEventListener('click', ()=>{
  try{ localStorage.removeItem('nexhelp_auth'); }catch{}
  location.href = 'index.html';
});
els.logoutDialog?.addEventListener('click', (e)=>{
  if (e.target.classList.contains('backdrop')) closeLogoutModal();
});

/* ==== Teclas de atalho ==== */
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape'){
    if (!els.profileMenu.hidden) els.profileMenu.hidden = true;
    if (!els.moreMenu.hidden) els.moreMenu.hidden = true;
    if (!els.chatTagsMenu.hidden) els.chatTagsMenu.hidden = true;
    if (!els.emojiPanel.hidden) els.emojiPanel.hidden = true;
    if (!els.attachMenu.hidden) els.attachMenu.hidden = true;
    if (!els.logoutDialog.hidden) closeLogoutModal();
    if (!els.transferDialog.hidden) closeTransferModal();
  }
});

/* ==== INTEGRAÇÃO OPENAI ==== */
async function generateAIResponse(userMessage) {
  if (!state.currentChatId) return;

  // Carrega prompts configurados
  const prompts = JSON.parse(localStorage.getItem('nexhelp_openai_prompts') || '[]');
  const found = chatById(state.currentChatId);
  if (!found) return;

  // Encontra prompt para a fila atual
  const prompt = prompts.find(p => 
    (p.queues || []).includes(found.row.fila) && p.apiKey
  );

  if (!prompt) {
    // Sem prompt configurado, resposta padrão
    setTimeout(() => {
      addMsg({
        me: false,
        text: 'Obrigado pela sua mensagem! Nossa equipe irá responder em breve.',
        date: Date.now(),
        status: 'received'
      });
    }, 1000);
    return;
  }

  // Coleta histórico recente (últimas N mensagens)
  const history = [];
  const msgElements = els.chatBody.querySelectorAll('.msg');
  const maxHistory = prompt.maxHistory || 10;
  
  Array.from(msgElements).slice(-maxHistory).forEach(msgEl => {
    const isOut = msgEl.classList.contains('msg-out');
    const text = msgEl.querySelector('.msg-bubble')?.textContent?.trim();
    if (text) {
      history.push({
        role: isOut ? 'user' : 'assistant',
        content: text
      });
    }
  });

  // Adiciona mensagem atual
  history.push({ role: 'user', content: userMessage });

  // Mostra indicador de "digitando..."
  const typingIndicator = document.createElement('div');
  typingIndicator.className = 'msg msg-in';
  typingIndicator.innerHTML = `
    <div class="msg-bubble">
      <span class="typing-dots">
        <span></span><span></span><span></span>
      </span>
    </div>
  `;
  els.chatBody.appendChild(typingIndicator);
  els.chatBody.scrollTop = els.chatBody.scrollHeight;

  try {
    // Chama API OpenAI (mock por enquanto - em produção, usar API real)
    const response = await callOpenAI(prompt.apiKey, history, prompt.maxTokens || 150);
    
    // Remove indicador de digitação
    typingIndicator.remove();
    
    // Adiciona resposta
    addMsg({
      me: false,
      text: response || 'Desculpe, não consegui processar sua mensagem no momento.',
      date: Date.now(),
      status: 'received'
    });
  } catch (err) {
    typingIndicator.remove();
    addMsg({
      me: false,
      text: 'Desculpe, ocorreu um erro ao processar sua mensagem. Nossa equipe será notificada.',
      date: Date.now(),
      status: 'received'
    });
    console.error('OpenAI error:', err);
  }
}

async function callOpenAI(apiKey, messages, maxTokens) {
  // MOCK: Simula chamada à API OpenAI
  // Em produção, substituir por chamada real:
  /*
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'Você é um assistente de suporte técnico. Seja prestativo e profissional.' },
        ...messages
      ],
      max_tokens: maxTokens,
      temperature: 0.7
    })
  });
  const data = await response.json();
  return data.choices[0]?.message?.content || '';
  */

  // Simulação de resposta
  await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));
  
  const responses = [
    'Entendo sua situação. Vou verificar isso para você.',
    'Obrigado por entrar em contato. Nossa equipe está trabalhando para resolver isso.',
    'Compreendo sua necessidade. Deixe-me ajudá-lo com isso.',
    'Vou encaminhar sua solicitação para nossa equipe técnica.',
    'Obrigado pela informação. Estamos analisando seu caso.'
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}

/* ==== Toggle bot no chat atual ==== */
els.botToggle?.addEventListener('change', ()=>{
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  found.row.bot = els.botToggle.checked;
});

/* ==== Deletar / Exportar ==== */
els.deleteChatBtn?.addEventListener('click', ()=>{
  if (!state.currentChatId) return;
  const found = chatById(state.currentChatId); if (!found) return;
  if (!confirm('Tem certeza que deseja deletar este chamado?')) return;
  getList(found.list).splice(found.index,1);
  renderLists();
  state.currentChatId=null; state.currentChatListName=null;
  els.chatBody.innerHTML=''; els.chatBody.appendChild(els.chatEmpty);
  setHeaderEmpty(); setChatEmpty(true);
});

els.exportPdfBtn?.addEventListener('click', ()=>{
  const win = window.open('', '_blank');
  const theme = document.documentElement.getAttribute('data-theme')||'light';
  const title = `${els.chatTitle.textContent} (${els.chatId.textContent}) — Histórico`;
  const html = `
  <html><head>
    <meta charset="utf-8" />
    <title>${esc(title)}</title>
    <style>
      body{ font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin:20px; }
      h1{ font-size:18px; margin:0 0 8px; }
      .msg{ margin:6px 0; padding:10px 12px; border-radius:10px; max-width:70%; }
      .in{ background:#f1f1f7; }
      .out{ background:#e7e3ff; margin-left:auto; }
      ${theme==='dark' ? `
        body{ background:#111827; color:#e5e7eb; }
        .in{ background:#1f2937; }
        .out{ background:#32295a; color:#fff; }
      `:''}
      img{ max-width:400px; display:block; border-radius:8px; }
    </style>
  </head><body>
    <h1>${esc(title)}</h1>
    ${[...els.chatBody.querySelectorAll('.msg')].map(m=>{
      const out = m.classList.contains('msg-out');
      const img = m.querySelector('img');
      if (img) return `<div class="msg ${out?'out':'in'}"><img src="${img.src}"></div>`;
      const text = m.querySelector('.msg-bubble')?.textContent?.trim() || '';
      return `<div class="msg ${out?'out':'in'}">${esc(text)}</div>`;
    }).join('')}
    <script>window.onload=()=>{ window.print(); }</script>
  </body></html>`;
  win.document.write(html); win.document.close();
});

/* ==== ÁUDIO (gravação real) ==== */
let recordingStartTime = null;
let recordingTimer = null;

els.audioBtn?.addEventListener('click', async ()=>{
  if (state.currentChatListName === 'finalizados' || els.composerInput.disabled) return;

  const composer = document.querySelector('.chat-composer');

  if (!isRecording){
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined'){
      alert('Seu navegador não suporta gravação de áudio.');
      return;
    }
    try{
      mediaStream = await navigator.mediaDevices.getUserMedia({ audio:true });
      mediaRecorder = new MediaRecorder(mediaStream);
      recChunks = [];
      recordingStartTime = Date.now();
      
      mediaRecorder.ondataavailable = (e)=>{ if (e.data && e.data.size) recChunks.push(e.data); };

      mediaRecorder.onstop = ()=>{
        try{ mediaStream.getTracks().forEach(t=>t.stop()); }catch{}
        if (recordingTimer) {
          clearInterval(recordingTimer);
          recordingTimer = null;
        }
        
        // Verifica se foi cancelado (gravação muito curta ou chunks vazios)
        const duration = Date.now() - recordingStartTime;
        const mime = mediaRecorder.mimeType || 'audio/webm';
        const blob = new Blob(recChunks, { type: mime });
        
        // Se a gravação foi muito curta (< 500ms) ou blob vazio, considera cancelado
        if (duration < 500 || !blob || blob.size === 0){
          isRecording = false;
          composer?.classList.remove('recording');
          els.audioBtn.title = 'Gravar áudio';
          recChunks = []; // Limpa chunks
          return;
        }
        
        // Gravação válida - envia mensagem
        const url = URL.createObjectURL(blob);
        const durMs = duration;
        addMsg({ me:true, type:'audio', src:url, durationMs:durMs, status:'sent', date:Date.now() });
        recChunks = []; // Limpa após enviar
      };

      mediaRecorder.start();
      isRecording = true;
      composer?.classList.add('recording');
      els.audioBtn.title = 'Parar gravação (clique novamente para cancelar)';
      
      // Timer visual (opcional - pode mostrar no botão)
      recordingTimer = setInterval(() => {
        const elapsed = Date.now() - recordingStartTime;
        els.audioBtn.title = `Parar gravação (${formatClock(elapsed)})`;
      }, 1000);
      
    }catch(err){
      alert('Não foi possível acessar o microfone.');
      console.error(err);
    }
    return;
  }

  // Parar gravação
  const duration = Date.now() - recordingStartTime;
  const wasShort = duration < 500;
  
  try{
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      // Se foi muito curto, cancela antes de parar
      if (wasShort) {
        recChunks = [];
        try{ mediaStream?.getTracks().forEach(t=>t.stop()); }catch{}
        mediaRecorder.stop(); // Para o recorder mesmo assim para limpar
      } else {
        mediaRecorder.stop(); // Para normalmente e envia
      }
    }
  }catch(err){
    console.error('Erro ao parar gravação:', err);
  }finally{
    isRecording = false;
    if (recordingTimer) {
      clearInterval(recordingTimer);
      recordingTimer = null;
    }
    composer?.classList.remove('recording');
    els.audioBtn.title = 'Gravar áudio';
    
    // Se foi cancelado, limpa tudo
    if (wasShort) {
      recChunks = [];
      try{ mediaStream?.getTracks().forEach(t=>t.stop()); }catch{}
    }
  }
});

/* ==== INDICADOR DE STATUS DE CONEXÃO ==== */
function updateConnectionStatus() {
  const indicator = document.getElementById('connStatusIndicator');
  if (!indicator) return;

  try {
    const connections = JSON.parse(localStorage.getItem('nexhelp_telegram_connections') || '[]');
    const connected = connections.some(c => c.connected);
    
    const srOnly = indicator.querySelector('.sr-only');
    const statusIcon = indicator.querySelector('.status-icon');
    
    if (!statusIcon) return; // Se não existe, não atualiza
    
    if (connected) {
      indicator.classList.add('connected');
      indicator.classList.remove('disconnected');
      statusIcon.setAttribute('data-icon', 'check');
      statusIcon.className = 'status-icon icon';
      if (srOnly) srOnly.textContent = 'Conexão Telegram: Conectado';
      indicator.title = 'Conexão Telegram: Conectado';
    } else {
      indicator.classList.add('disconnected');
      indicator.classList.remove('connected');
      statusIcon.setAttribute('data-icon', 'x');
      statusIcon.className = 'status-icon icon';
      if (srOnly) srOnly.textContent = 'Conexão Telegram: Desconectado';
      indicator.title = 'Conexão Telegram: Desconectado';
    }
    
    document.dispatchEvent(new CustomEvent('icons:refresh'));
  } catch {}
}

// Atualiza status periodicamente e ao carregar
updateConnectionStatus();
setInterval(updateConnectionStatus, 5000);

// Atualiza quando conexões mudam
window.addEventListener('storage', (e) => {
  if (e.key === 'nexhelp_telegram_connections') {
    updateConnectionStatus();
  }
});

/* ========= iniciar ========= */
setHeaderEmpty();
moveUnderline();
setChatEmpty(true); // inicia SEM chat aberto (só a lista visível)
updateComposerButtons(); // garante áudio padrão visível
