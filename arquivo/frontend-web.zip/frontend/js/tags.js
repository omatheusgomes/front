// js/tags.js
const els = {
  tagSearch: document.getElementById('tagSearch'),
  newTagBtn: document.getElementById('newTagBtn'),
  tbody: document.getElementById('tagsTbody'),
  footer: document.getElementById('tableFooter'),
  // dialog de tag
  tagDialog: document.getElementById('tagDialog'),
  tagDialogTitle: document.getElementById('tagDialogTitle'),
  tagForm: document.getElementById('tagForm'),
  tagName: document.getElementById('tagName'),
  tagColor: document.getElementById('tagColor'),
  tagPreview: document.getElementById('tagPreview'),
  editingId: document.getElementById('editingId'),
  dlgCancel: document.getElementById('dlgCancel'),
  dlgSave: document.getElementById('dlgSave'),
  // confirmar exclusão
  confirmDialog: document.getElementById('confirmDialog'),
  confirmCancel: document.getElementById('confirmCancel'),
  confirmDelete: document.getElementById('confirmDelete'),
  // profile/logout
  profileBtn: document.getElementById('profileBtn'),
  profileMenu: document.getElementById('profileMenu'),
  myProfileBtn: document.getElementById('myProfileBtn'),
  logoutBtn: document.getElementById('logoutBtn'),
  logoutDialog: document.getElementById('logoutDialog'),
  logoutCancel: document.getElementById('logoutCancel'),
  logoutConfirm: document.getElementById('logoutConfirm'),
};

// dataset inicial (mock) — INICIAR VAZIO
let tags = [];

const state = { filter: '' };

const esc = (s) => String(s).replace(/[&<>"']/g, m =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

// contraste de texto automático para o selo
function pickTextColor(hex){
  const c = (hex||'#777').replace('#','');
  const r = parseInt(c.substr(0,2),16);
  const g = parseInt(c.substr(2,2),16);
  const b = parseInt(c.substr(4,2),16);
  const l = (0.2126*r + 0.7152*g + 0.0722*b) / 255;
  return (l > 0.6) ? '#1f2937' : '#ffffff';
}

function render(){
  const q = state.filter.trim().toLowerCase();
  const rows = tags.filter(t => !q || t.name.toLowerCase().includes(q) || String(t.id).includes(q));

  els.tbody.innerHTML = rows.map(t => `
    <tr role="row">
      <td class="col-id">${t.id}</td>
      <td class="col-name">
        <span class="tag-badge" style="--tag-bg:${t.color};--tag-fg:${pickTextColor(t.color)}">${esc(t.name)}</span>
      </td>
      <td class="col-count">
        <div class="count-cell">
          <span class="count-num">${t.contacts}</span>
          <button class="icon-btn ghost sm" title="Ver contatos desta tag" data-view="${t.id}">
            <span class="icon" data-icon="ellipsis"></span>
          </button>
        </div>
      </td>
      <td class="col-actions">
        <div class="actions-cell">
          <button class="icon-btn ghost sm" title="Editar" data-edit="${t.id}">
            <span class="icon" data-icon="pencil"></span>
          </button>
          <button class="icon-btn ghost sm danger" title="Excluir" data-del="${t.id}">
            <span class="icon" data-icon="trash-2"></span>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  els.footer.textContent = `${rows.length} ${rows.length===1?'tag':'tags'}`;
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}
render();

/* busca */
els.tagSearch?.addEventListener('input', ()=>{
  state.filter = els.tagSearch.value || '';
  render();
});

/* abrir modal nova/editar */
function openTagDialog(edit){
  els.tagDialog.hidden = false;
  // garante que o form não sugere histórico
  els.tagForm?.setAttribute('autocomplete','off');

  if (edit){
    els.tagDialogTitle.textContent = 'Editar tag';
    els.editingId.value = String(edit.id);
    els.tagName.value = edit.name;
    els.tagColor.value = edit.color;
  }else{
    els.tagDialogTitle.textContent = 'Nova tag';
    els.editingId.value = '';
    els.tagName.value = '';
    els.tagColor.value = '#22c55e';
  }
  els.tagName.placeholder = 'Nome';

  updatePreview();
  els.dlgSave.disabled = !els.tagName.value.trim();
  els.tagName.focus();
}
function closeTagDialog(){ els.tagDialog.hidden = true; }
function updatePreview(){
  els.tagPreview.textContent = (els.tagName.value || 'NOVA TAG').toUpperCase();
  const bg = els.tagColor.value || '#22c55e';
  els.tagPreview.style.setProperty('--tag-bg', bg);
  els.tagPreview.style.setProperty('--tag-fg', pickTextColor(bg));
}
els.tagName?.addEventListener('input', ()=>{ updatePreview(); els.dlgSave.disabled = !els.tagName.value.trim(); });
els.tagColor?.addEventListener('input', updatePreview);
els.newTagBtn?.addEventListener('click', ()=>openTagDialog(null));
els.dlgCancel?.addEventListener('click', closeTagDialog);

els.dlgSave?.addEventListener('click', ()=>{
  const name = els.tagName.value.trim(); if(!name) return;
  const color = els.tagColor.value || '#22c55e';
  const idEditing = els.editingId.value.trim();

  if (idEditing){
    const idx = tags.findIndex(t=>String(t.id)===idEditing);
    if (idx>-1){ tags[idx].name = name.toUpperCase(); tags[idx].color=color; }
  }else{
    const nextId = (tags.reduce((m,t)=>Math.max(m,t.id),0) || 0) + 1;
    tags.unshift({ id: nextId, name: name.toUpperCase(), color, contacts: 0 });
  }
  closeTagDialog();
  render();
});

/* ações da tabela (delegação) — corrige data-view */
els.tbody?.addEventListener('click', (e)=>{
  const btn = e.target.closest('button[data-edit],button[data-del],button[data-view]');
  if (!btn) return;

  const id = Number(btn.dataset.edit || btn.dataset.del || btn.dataset.view);
  const row = tags.find(t=>t.id===id);
  if (!row) return;

  if (btn.dataset.edit){
    openTagDialog(row);
    return;
  }
  if (btn.dataset.del){
    pendingDeleteId = id;
    els.confirmDialog.hidden = false;
    els.confirmCancel.focus();
    return;
  }
  if (btn.dataset.view){
    alert(`Contatos da tag "${row.name}" — virá em breve 🙂`);
    return;
  }
});

/* confirmar exclusão */
let pendingDeleteId = null;
function closeConfirm(){ els.confirmDialog.hidden = true; pendingDeleteId = null; }
els.confirmCancel?.addEventListener('click', closeConfirm);
els.confirmDelete?.addEventListener('click', ()=>{
  if (pendingDeleteId!=null){
    tags = tags.filter(t=>t.id!==pendingDeleteId);
    render();
  }
  closeConfirm();
});

/* Perfil / logout */
function togglePanel(btn, panel){
  const will = panel.hasAttribute('hidden');
  panel.toggleAttribute('hidden', !will);
  if (will){
    setTimeout(()=>{
      const closer=(e)=>{ if(!panel.contains(e.target) && e.target!==btn){ panel.hidden=true; document.removeEventListener('click', closer);} };
      document.addEventListener('click', closer);
    },0);
  }
}
els.profileBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); togglePanel(els.profileBtn, els.profileMenu); });
els.myProfileBtn?.addEventListener('click', ()=>{ els.profileMenu.hidden = true; });
els.logoutBtn?.addEventListener('click', ()=>{ els.profileMenu.hidden = true; els.logoutDialog.hidden = false; els.logoutCancel.focus(); });
els.logoutCancel?.addEventListener('click', ()=>{ els.logoutDialog.hidden = true; });
els.logoutConfirm?.addEventListener('click', ()=>{
  try{ localStorage.removeItem('nexhelp_auth'); }catch{}
  location.href = 'index.html';
});

/* ESC fecha popovers/modais */
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape'){
    if (!els.profileMenu.hidden) els.profileMenu.hidden = true;
    if (!els.tagDialog.hidden) els.tagDialog.hidden = true;
    if (!els.confirmDialog.hidden) els.confirmDialog.hidden = true;
    if (!els.logoutDialog.hidden) els.logoutDialog.hidden = true;
  }
});
