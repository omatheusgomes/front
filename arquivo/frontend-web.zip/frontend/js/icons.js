// js/icons.js — carrega SVGs de /icons e injeta inline com currentColor.
// Mantém fallbacks para não quebrar nada.

const ICON_ALIASES = { openai: 'openaii' };

const FALLBACK_PATHS = {
  send:'M22 2L11 13M22 2l-7 20-4-9-9-4 20-7',
  'send-horizontal':'M3 12h18M15 5l7 7-7 7',
  'layout-dashboard':'M3 3h8v8H3zM13 3h8v5h-8zM13 10h8v11h-8zM3 13h8v8H3z',
  'notebook-text':'M4 3h14a2 2 0 0 1 2 2v14H4zM8 7h8M8 11h8M8 15h5',
  'book-user':'M2 20V4a2 2 0 0 1 2-2h9l5 5v13a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2zM12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4z',
  tags:'M3 7l9-4 9 4-9 4-9-4zM3 12l9 4 9-4',
  openai:'M12 2a10 10 0 1 1-10 10A10 10 0 0 1 12 2z',
  cable:'M3 12h6M15 12h6M9 12V5M15 19v-7',
  users:'M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M12 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  settings:'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7',
  bell:'M6 8a6 6 0 1 1 12 0v5l2 2H4l2-2zM10 21h4',
  'circle-user-round':'M12 14a5 5 0 1 0-5-5 5 5 0 0 0 5 5zM2 22a10 10 0 0 1 20 0',
  sun:'M12 4V2M12 22v-2M4.22 4.22 2.81 2.81M21.19 21.19 19.78 19.78M4 12H2M22 12h-2M6.34 17.66l-1.41 1.41M19.07 6.93l1.41-1.41M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  moon:'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z',

  'chevron-left':'M15 18l-6-6 6-6',
  'circle-check':'M12 22a10 10 0 1 1 0-20 10 10 0 0 1 0 20zM8.5 12.5l2.5 2.5 4.5-5',
  'undo':'M3 7h7a6 6 0 1 1-6 6M3 7l4-4M3 7l4 4',
  'arrow-right-left':'M21 7H7m0 0 4-4M7 7l4 4M3 17h14m0 0-4-4m4 4-4 4',
  'ellipsis-vertical':'M12 5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z',
  'smile':'M12 22a10 10 0 1 1 0-20 10 10 0 0 1 0 20zm-4-9a4 4 0 0 0 8 0M9 9h.01M15 9h.01',
  'paperclip':'M21.44 11.05 12.7 19.8a6 6 0 0 1-8.49-8.49L13.7 1.82',
  'mic':'M12 14a4 4 0 0 0 4-4V5a4 4 0 1 0-8 0v5a4 4 0 0 0 4 4zm6-4a6 6 0 1 1-12 0M12 20v2',
  'image':'M3 3h18v18H3zM21 15l-5-5-4 4-3-3-6 6',
  'file':'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12V8zM14 2v6h6',
  'check':'M5 13l4 4L19 7',
  'checks':'M3 13l4 4L17 7M8 13l4 4L22 7'
};

const cache = new Map();

async function fetchSvgText(name) {
  const tryNames = [name, ICON_ALIASES[name]].filter(Boolean);
  for (const n of tryNames) {
    const url = `icons/${n}.svg`;
    try {
      const res = await fetch(url, { cache: 'force-cache' });
      if (res.ok) return await res.text();
    } catch {}
  }
  return null;
}

function normalizeSvg(svg) {
  return svg
    .replace(/<\?xml[^>]*>/g, '')
    .replace(/<!DOCTYPE[^>]*>/g, '')
    .replace(/fill="(?!none)[^"]*"/gi, 'fill="none"')
    .replace(/stroke="[^"]*"/gi, 'stroke="currentColor"')
    .replace(/stroke-width="[^"]*"/gi, '')
    .replace(/<svg([^>]*)>/, '<svg$1 aria-hidden="true">');
}

async function renderIcon(el){
  const name = el.getAttribute('data-icon');
  if (!name) return;

  const already = el.getAttribute('data-icon-rendered');
  if (already === name) return;

  let svg = cache.get(name) || null;
  if (!svg) {
    const txt = await fetchSvgText(name);
    if (txt) {
      svg = normalizeSvg(txt);
      cache.set(name, svg);
    }
  }
  if (!svg && FALLBACK_PATHS[name]) {
    svg = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${FALLBACK_PATHS[name]}"/></svg>`;
  }
  if (!svg) {
    el.textContent = '•';
    el.style.fontSize = '1rem';
    return;
  }
  el.innerHTML = svg;
  el.setAttribute('data-icon-rendered', name);
}

function refreshAll(){ document.querySelectorAll('.icon').forEach((el) => renderIcon(el)); }
refreshAll();
document.addEventListener('icons:refresh', refreshAll);

const mo = new MutationObserver((muts) => {
  for (const m of muts){
    if (m.type === 'childList'){
      m.addedNodes?.forEach(n => {
        if (n?.nodeType === 1){
          if (n.classList?.contains('icon')) renderIcon(n);
          n.querySelectorAll?.('.icon')?.forEach(renderIcon);
        }
      });
    } else if (m.type === 'attributes' && m.target?.classList?.contains('icon')){
      renderIcon(m.target);
    }
  }
});
mo.observe(document.documentElement, { subtree:true, childList:true, attributes:true, attributeFilter:['data-icon'] });

Object.assign(FALLBACK_PATHS, {
  plus: 'M12 5v14M5 12h14',
  search: 'M21 21l-4.35-4.35M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16',
  pencil: 'M3 21l3.75-.6L20 7.15 16.85 4 4.35 16.5zM14 6l4 4',
  'trash-2': 'M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2',
  ellipsis: 'M5 12a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm7 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm7 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3',
  menu: 'M3 12h18M3 6h18M3 18h18',
  'chevron-down': 'M6 9l6 6 6-6',
  eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  'eye-off': 'M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22',
  'circle-x': 'M12 22a10 10 0 1 1 0-20 10 10 0 0 1 0 20zM15 9l-6 6m0-6l6 6'
});
