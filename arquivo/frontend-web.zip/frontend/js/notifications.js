// js/notifications.js - Sistema de notificações global
(function() {
  'use strict';
  
  const NOTIFICATIONS_KEY = 'nexhelp_notifications';
  
  // Carrega notificações do localStorage
  function loadNotifications() {
    try {
      const raw = localStorage.getItem(NOTIFICATIONS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  }
  
  // Salva notificações no localStorage
  function saveNotifications(notifications) {
    try {
      localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
    } catch {}
  }
  
  // Inicializa o painel de notificações em todas as páginas
  function initNotifications() {
    const bellBtn = document.querySelector('.icon-btn[title="Notificações"], .icon-btn[title*="Notificações"]');
    if (!bellBtn) return;
    
    // Cria o painel de notificações se não existir
    let panel = document.getElementById('notificationsPanel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'notificationsPanel';
      panel.className = 'menu-panel notifications-panel';
      panel.setAttribute('role', 'menu');
      panel.setAttribute('aria-label', 'Notificações');
      panel.hidden = true;
      
      // Envolve o botão em um menu-anchor se ainda não estiver
      let wrapper = bellBtn.closest('.menu-anchor');
      if (!wrapper) {
        wrapper = document.createElement('div');
        wrapper.className = 'menu-anchor';
        const parent = bellBtn.parentElement;
        parent.insertBefore(wrapper, bellBtn);
        wrapper.appendChild(bellBtn);
      }
      wrapper.appendChild(panel);
    }
    
    // Atualiza o painel
    function renderNotifications() {
      const notifications = loadNotifications();
      
      if (notifications.length === 0) {
        panel.innerHTML = `
          <div class="notifications-empty">
            <span class="icon" data-icon="bell" style="opacity:.3; inline-size:2rem; block-size:2rem;"></span>
            <p>Nenhuma notificação</p>
          </div>
        `;
      } else {
        panel.innerHTML = notifications.map(n => `
          <div class="notification-item ${n.read ? 'read' : 'unread'}" data-id="${n.id}">
            <div class="notification-content">
              <strong>${escapeHTML(n.title || 'Notificação')}</strong>
              <p>${escapeHTML(n.message || '')}</p>
              <span class="notification-time">${formatTime(n.date || Date.now())}</span>
            </div>
          </div>
        `).join('');
      }
      
      document.dispatchEvent(new CustomEvent('icons:refresh'));
    }
    
    // Toggle do painel
    function togglePanel() {
      const isHidden = panel.hasAttribute('hidden');
      panel.toggleAttribute('hidden', !isHidden);
      bellBtn.setAttribute('aria-expanded', String(!isHidden));
      
      if (!isHidden) {
        renderNotifications();
        setTimeout(() => {
          const closer = (e) => {
            if (!panel.contains(e.target) && e.target !== bellBtn) {
              panel.hidden = true;
              bellBtn.setAttribute('aria-expanded', 'false');
              document.removeEventListener('click', closer);
            }
          };
          document.addEventListener('click', closer);
        }, 0);
      }
    }
    
    bellBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      togglePanel();
    });
    
    // Renderiza inicialmente
    renderNotifications();
  }
  
  function escapeHTML(str) {
    return String(str).replace(/[&<>"']/g, m => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    })[m]);
  }
  
  function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = Date.now();
    const diff = now - timestamp;
    
    if (diff < 60000) return 'Agora';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} min atrás`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} h atrás`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)} dias atrás`;
    
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  }
  
  // Inicializa quando o DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initNotifications);
  } else {
    initNotifications();
  }
})();

