// js/login.js — mock simples
document.getElementById('login-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  try{
    localStorage.setItem('nexhelp_auth', JSON.stringify({ at: Date.now() }));
  }catch{}
  location.href = 'chamados.html';
});
