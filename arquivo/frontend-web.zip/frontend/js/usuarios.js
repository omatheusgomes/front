// js/usuarios.js
// Página de Usuários — segue o mesmo padrão de interação das outras listas

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

const storeKey = "nx_users";

// ====== Estado ======
let users = load();
let editingId = null;         // null => novo, número => editando
let pendingDeleteId = null;

// ====== DOM ======
const tbody = $("#usersTbody");
const counter = $("#usersCounter");
const searchInput = $("#usersSearch");
const searchBox = $("#usersSearchbox");
const searchBtn = $("#usersSearchBtn");

const addUserBtn = $("#addUserBtn");
const userDialog = $("#userDialog");
const userForm = $("#userForm");
const userDlgCancel = $("#userDlgCancel");

const delDialog = $("#delUserDialog");
const delCancel = $("#delUserCancel");
const delConfirm = $("#delUserConfirm");

// Perfil (mesmo comportamento das outras telas)
const profileBtn = $("#profileBtn");
const profileMenu = $("#profileMenu");
document.addEventListener("click", (e) => {
  if (profileBtn.contains(e.target)) {
    const isOpen = !profileMenu.hasAttribute("hidden");
    profileMenu.toggleAttribute("hidden", isOpen);
    profileBtn.setAttribute("aria-expanded", String(!isOpen));
  } else if (!profileMenu.contains(e.target)) {
    profileMenu.setAttribute("hidden", "");
    profileBtn.setAttribute("aria-expanded", "false");
  }
});

// ====== Renderização ======
function render(list = users) {
  const q = searchInput.value.trim().toLowerCase();
  const filtered = q
    ? list.filter(u => (u.name + " " + u.email).toLowerCase().includes(q))
    : list;

  tbody.innerHTML = filtered.map(u => rowHTML(u)).join("") || emptyHTML();
  counter.textContent = `${filtered.length} usuário${filtered.length === 1 ? "" : "s"}`;

  // ações linha
  $$(".act-edit", tbody).forEach(btn => btn.addEventListener("click", onEdit));
  $$(".act-del", tbody).forEach(btn => btn.addEventListener("click", onAskDelete));
  $$(".status-btn", tbody).forEach(btn => btn.addEventListener("click", onToggleStatus));

  // refresh do sistema de ícones (para os botões de ação)
  document.dispatchEvent(new CustomEvent("icons:refresh"));
}

function rowHTML(u) {
  const online = !!u.active;
  const title = online ? "Online — clicar para ficar offline" : "Offline — clicar para ficar online";

  return `
  <tr role="row" data-id="${u.id}">
    <td class="col-id">${u.id}</td>
    <td class="col-status">
      <button class="status-btn" type="button" title="${title}" aria-label="${title}">
        <span class="status-ico ${online ? "online" : "offline"}" aria-hidden="true"></span>
      </button>
    </td>
    <td class="col-name">${escapeHTML(u.name)}</td>
    <td class="col-email">${escapeHTML(u.email)}</td>
    <td class="col-role">${u.role === "admin" ? "Admin" : "Técnico"}</td>
    <td class="col-actions">
      <div class="row-actions">
        <button class="icon-btn ghost sm act-edit" title="Editar usuário" type="button">
          <span class="icon" data-icon="pencil"></span>
        </button>
        <button class="icon-btn ghost sm danger act-del" title="Excluir usuário" type="button">
          <span class="icon" data-icon="trash-2"></span>
        </button>
      </div>
    </td>
  </tr>`;
}

function emptyHTML(){
  return `<tr><td colspan="6" style="padding:1rem .9rem;color:var(--ink-700)">Nenhum usuário cadastrado.</td></tr>`;
}

// ====== Util ======
function load(){
  try{ return JSON.parse(localStorage.getItem(storeKey)) || []; }catch{ return []; }
}
function save(){ localStorage.setItem(storeKey, JSON.stringify(users)); }
function nextId(){ return users.length ? Math.max(...users.map(u=>u.id)) + 1 : 1; }
function escapeHTML(s){ return String(s).replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m])); }
function openDialog(el){ el.removeAttribute("hidden"); }
function closeDialog(el){ el.setAttribute("hidden",""); }

// ====== Busca ======
function syncSearchAdornment(){
  searchBox.classList.toggle("has-value", !!searchInput.value.trim());
}
searchInput.addEventListener("input", () => { syncSearchAdornment(); render(); });
searchBtn.addEventListener("click", () => {
  if (searchInput.value.trim()) { searchInput.value = ""; }
  searchInput.dispatchEvent(new Event("input"));
});

// ====== Novo / Editar ======
addUserBtn.addEventListener("click", () => {
  editingId = null;
  $("#userDialogTitle").textContent = "Novo usuário";
  $("#userDialogHint").textContent = "Preencha os dados do usuário.";
  userForm.reset();
  openDialog(userDialog);
  $("#userName").focus();
});

userDlgCancel.addEventListener("click", () => closeDialog(userDialog));

userForm.addEventListener("submit", () => {
  const data = {
    name: $("#userName").value.trim(),
    email: $("#userEmail").value.trim(),
    password: $("#userPass").value,     // placeholder/local apenas
    role: $("#userRole").value,
  };
  if (!data.name || !data.email || !data.password) return;

  if (editingId == null) {
    users.push({ id: nextId(), active: true, ...data });
  } else {
    const idx = users.findIndex(u => u.id === editingId);
    if (idx >= 0) users[idx] = { ...users[idx], ...data };
  }
  save();
  closeDialog(userDialog);
  render();
});

// botão editar
function onEdit(e){
  const tr = e.currentTarget.closest("tr");
  const id = Number(tr.dataset.id);
  const u = users.find(x => x.id === id);
  if (!u) return;

  editingId = id;
  $("#userDialogTitle").textContent = "Editar usuário";
  $("#userDialogHint").textContent = "Atualize os dados do usuário.";
  $("#userName").value = u.name;
  $("#userEmail").value = u.email;
  $("#userPass").value = u.password || "";
  $("#userRole").value = u.role;
  openDialog(userDialog);
}

// alternar status
function onToggleStatus(e){
  const tr = e.currentTarget.closest("tr");
  const id = Number(tr.dataset.id);
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  users[idx].active = !users[idx].active;
  save();
  render();
}

// ====== Exclusão ======
function onAskDelete(e){
  const tr = e.currentTarget.closest("tr");
  pendingDeleteId = Number(tr.dataset.id);
  openDialog(delDialog);
}
delCancel.addEventListener("click", () => { pendingDeleteId = null; closeDialog(delDialog); });
delConfirm.addEventListener("click", () => {
  if (pendingDeleteId != null){
    users = users.filter(u => u.id !== pendingDeleteId);
    save();
    render();
  }
  pendingDeleteId = null;
  closeDialog(delDialog);
});

// ====== Atalhos / Fechar modais ao clicar no backdrop ======
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("backdrop")){
    const dlg = e.target.parentElement;
    closeDialog(dlg);
  }
});

// ====== Inicialização ======
render();
syncSearchAdornment();

// Ação rápida “Sair” do menu de perfil
$("#logoutBtn")?.addEventListener("click", () => {
  localStorage.removeItem("authToken");
  window.location.href = "login.html";
});
