// js/conexoes.js
const els = {
  tbody: document.getElementById('connTbody'),
  counter: document.getElementById('connCounter'),

  newBtn: document.getElementById('newConnBtn'),
  dlg: document.getElementById('connDialog'),
  dlgCancel: document.getElementById('connDlgCancel'),
  dlgSave: document.getElementById('connDlgSave'),

  // delete confirm
  delDlg: document.getElementById('delDialog'),
  delCancel: document.getElementById('delCancel'),
  delConfirm: document.getElementById('delConfirm'),

  // disconnect confirm
  discDlg: document.getElementById('discDialog'),
  discCancel: document.getElementById('discCancel'),
  discConfirm: document.getElementById('discConfirm'),

  // perfil/logout
  profileBtn: document.getElementById('profileBtn'),
  profileMenu: document.getElementById('profileMenu'),
  logoutBtn: document.getElementById('logoutBtn'),
};

let pendingDeleteId = null;
let pendingDiscId = null;

// mock de conexões (Telegram) — INICIAR VAZIO
let connections = [];

// helpers
function esc(s){ return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }

function render(){
  els.tbody.innerHTML = connections.map(c => `
    <tr role="row" data-id="${c.id}">
      <td class="col-channel">
        <div class="channel">
          <img class="tg-logo" src="img/telegram-logo.png" alt="Telegram">
          <span>${esc(c.channel)}</span>
        </div>
      </td>
      <td class="col-name" title="${esc(c.name)}"><strong>${esc(c.name)}</strong></td>
      <td class="col-id">${esc(c.identifier||'—')}</td>
      <td class="col-status">
        <span class="status-pill ${c.connected?'ok':'off'}">
          <span class="icon" data-icon="${c.connected?'check':'x'}"></span>
          ${c.connected?'Conectado':'Desconectado'}
        </span>
      </td>
      <td class="col-session">
        <button class="btn ghost" data-toggle="${c.id}">
          ${c.connected ? 'Desconectar' : 'Conectar'}
        </button>
      </td>
      <td class="col-actions">
        <div style="display:flex;justify-content:flex-end;gap:.35rem">
          <button class="icon-btn ghost sm" title="Editar" data-edit="${c.id}">
            <span class="icon" data-icon="pencil"></span>
          </button>
          <button class="icon-btn ghost sm danger" title="Excluir" data-del="${c.id}">
            <span class="icon" data-icon="trash-2"></span>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  els.counter.textContent = `${connections.length} ${connections.length===1?'conexão':'conexões'}`;
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}

// delegação de eventos para a tabela
els.tbody?.addEventListener('click',(e)=>{
  const btn = e.target.closest('button[data-toggle],button[data-edit],button[data-del]');
  if(!btn) return;

  // abrir confirmação de conectar/desconectar
  if (btn.dataset.toggle){
    pendingDiscId = Number(btn.dataset.toggle);
    openDialog(els.discDlg);
    return;
  }

  if (btn.dataset.edit){
    openDialog(els.dlg); // placeholder
    return;
  }

  if (btn.dataset.del){
    pendingDeleteId = Number(btn.dataset.del);
    openDialog(els.delDlg);
    return;
  }
});

// modais utilitários
function openDialog(node){
  node.hidden = false;
  // foco no primeiro botão “primário”/seguro
  const firstBtn = node.querySelector('.actions .btn');
  if (firstBtn) firstBtn.focus();
}
function closeDialog(node){ node.hidden = true; }

/* Nova conexão (placeholder) */
els.newBtn?.addEventListener('click', ()=> openDialog(els.dlg));
els.dlgCancel?.addEventListener('click', ()=> closeDialog(els.dlg));
els.dlgSave?.addEventListener('click', ()=> closeDialog(els.dlg));

/* Excluir */
els.delCancel?.addEventListener('click', ()=>{ pendingDeleteId=null; closeDialog(els.delDlg); });
els.delConfirm?.addEventListener('click', ()=>{
  if (pendingDeleteId!=null){
    connections = connections.filter(c=>c.id!==pendingDeleteId);
    pendingDeleteId = null;
    render();
  }
  closeDialog(els.delDlg);
});

/* Desconectar / Conectar */
els.discCancel?.addEventListener('click', ()=>{ pendingDiscId=null; closeDialog(els.discDlg); });
els.discConfirm?.addEventListener('click', ()=>{
  if (pendingDiscId!=null){
    const idx = connections.findIndex(c=>c.id===pendingDiscId);
    if (idx>-1){
      // alterna estado
      connections[idx].connected = !connections[idx].connected;
    }
    pendingDiscId = null;
    render();
  }
  closeDialog(els.discDlg);
});

// Perfil / logout
function togglePanel(btn, panel){
  const will = panel.hasAttribute('hidden');
  panel.toggleAttribute('hidden', !will);
  if (will){
    setTimeout(()=>{
      const closer=(e)=>{ if(!panel.contains(e.target) && e.target!==btn){ panel.hidden=true; document.removeEventListener('click', closer);} };
      document.addEventListener('click', closer);
    },0);
  }
}
els.profileBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); togglePanel(els.profileBtn, els.profileMenu); });
els.logoutBtn?.addEventListener('click', ()=>{ try{localStorage.removeItem('nexhelp_auth');}catch{} location.href='index.html'; });

// ESC fecha modais
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape'){
    [els.dlg, els.delDlg, els.discDlg].forEach(m => { if(!m.hidden) m.hidden = true; });
  }
});

// init
render();
