// js/conexoes.js - Conexões Telegram com QR Code
const els = {
  tbody: document.getElementById('connTbody'),
  counter: document.getElementById('connCounter'),

  newBtn: document.getElementById('newConnBtn'),
  dlg: document.getElementById('connDialog'),
  dlgCancel: document.getElementById('connDlgCancel'),
  dlgSave: document.getElementById('connDlgSave'),

  // Abas do modal
  tabToken: document.getElementById('tab-token'),
  tabQr: document.getElementById('tab-qr'),
  panelToken: document.getElementById('panel-token'),
  panelQr: document.getElementById('panel-qr'),

  // Form Token
  connName: document.getElementById('connName'),
  connMethod: document.getElementById('connMethod'),
  tokenField: document.getElementById('tokenField'),
  phoneField: document.getElementById('phoneField'),
  codeField: document.getElementById('codeField'),
  connToken: document.getElementById('connToken'),
  connPhone: document.getElementById('connPhone'),
  connCode: document.getElementById('connCode'),
  toggleToken: document.getElementById('toggleToken'),
  tokenEyeIcon: document.getElementById('tokenEyeIcon'),

  // Form QR
  connQrName: document.getElementById('connQrName'),
  qrCanvas: document.getElementById('qrCanvas'),
  qrLoading: document.getElementById('qrLoading'),
  qrError: document.getElementById('qrError'),
  qrRetry: document.getElementById('qrRetry'),
  qrStatus: document.getElementById('qrStatus'),
  statusWaiting: document.getElementById('statusWaiting'),
  statusSuccess: document.getElementById('statusSuccess'),

  // delete confirm
  delDlg: document.getElementById('delDialog'),
  delCancel: document.getElementById('delCancel'),
  delConfirm: document.getElementById('delConfirm'),

  // disconnect confirm
  discDlg: document.getElementById('discDialog'),
  discCancel: document.getElementById('discCancel'),
  discConfirm: document.getElementById('discConfirm'),

  // logout
  logoutBtn: document.getElementById('logoutBtn'),
  logoutDialog: document.getElementById('logoutDialog'),
  logoutCancel: document.getElementById('logoutCancel'),
  logoutConfirm: document.getElementById('logoutConfirm'),
};

let pendingDeleteId = null;
let pendingDiscId = null;
let currentMethod = 'token'; // 'token' ou 'qr'
let qrPollInterval = null;
let qrSessionId = null;

// helpers
function esc(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[m]);
}

function loadFromStorage(key, defaultValue = []) {
  try {
    const raw = localStorage.getItem(`nexhelp_${key}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return defaultValue;
}

function saveToStorage(key, data) {
  try {
    localStorage.setItem(`nexhelp_${key}`, JSON.stringify(data));
  } catch {}
}

// Mock de conexões (carregado do localStorage)
let connections = loadFromStorage('telegram_connections', []);

function render() {
  els.tbody.innerHTML = connections.map(c => `
    <tr role="row" data-id="${c.id}">
      <td class="col-channel">
        <div class="channel">
          <img class="tg-logo" src="img/telegram-logo.png" alt="Telegram">
          <span>Telegram</span>
        </div>
      </td>
      <td class="col-name" title="${esc(c.name)}"><strong>${esc(c.name)}</strong></td>
      <td class="col-id">${esc(c.identifier || c.phone || '—')}</td>
      <td class="col-status">
        <span class="status-pill ${c.connected ? 'ok' : 'off'}">
          <span class="icon" data-icon="${c.connected ? 'circle-check' : 'circle-x'}"></span>
          ${c.connected ? 'Conectado' : 'Desconectado'}
        </span>
      </td>
      <td class="col-session">
        <button class="btn ghost" data-toggle="${c.id}" type="button">
          ${c.connected ? 'Desconectar' : 'Conectar'}
        </button>
      </td>
      <td class="col-actions">
        <div class="actions-cell">
          <button class="icon-btn sm" title="Editar" data-edit="${c.id}" type="button">
            <span class="icon" data-icon="pencil"></span>
          </button>
          <button class="icon-btn sm danger" title="Excluir" data-del="${c.id}" type="button">
            <span class="icon" data-icon="trash-2"></span>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  els.counter.textContent = `${connections.length} ${connections.length === 1 ? 'conexão' : 'conexões'}`;
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}

// ==== ABAS DO MODAL ====
function switchConnTab(tabName) {
  currentMethod = tabName;
  
  els.tabToken.classList.toggle('is-active', tabName === 'token');
  els.tabQr.classList.toggle('is-active', tabName === 'qr');
  els.tabToken.setAttribute('aria-selected', tabName === 'token');
  els.tabQr.setAttribute('aria-selected', tabName === 'qr');
  
  els.panelToken.style.display = tabName === 'token' ? 'block' : 'none';
  els.panelQr.style.display = tabName === 'qr' ? 'block' : 'none';
  els.panelToken.setAttribute('aria-hidden', tabName !== 'token');
  els.panelQr.setAttribute('aria-hidden', tabName !== 'qr');

  if (tabName === 'qr') {
    generateQRCode();
  } else {
    stopQRPolling();
  }
}

els.tabToken?.addEventListener('click', () => switchConnTab('token'));
els.tabQr?.addEventListener('click', () => switchConnTab('qr'));

// ==== MÉTODO DE AUTENTICAÇÃO ====
els.connMethod?.addEventListener('change', (e) => {
  const method = e.target.value;
  els.tokenField.style.display = method === 'token' ? 'block' : 'none';
  els.phoneField.style.display = method === 'phone' ? 'block' : 'none';
  els.codeField.style.display = 'none';
  
  if (method === 'phone') {
    els.connToken.required = false;
    els.connPhone.required = true;
  } else {
    els.connToken.required = true;
    els.connPhone.required = false;
  }
});

// Toggle mostrar/ocultar token
els.toggleToken?.addEventListener('click', () => {
  const showing = els.connToken.type !== 'password';
  els.connToken.type = showing ? 'password' : 'text';
  els.tokenEyeIcon?.setAttribute('data-icon', showing ? 'eye' : 'eye-off');
  document.dispatchEvent(new CustomEvent('icons:refresh'));
});

// ==== QR CODE ====
async function generateQRCode() {
  if (!els.qrCanvas || typeof QRCode === 'undefined') {
    console.error('QRCode library not loaded');
    return;
  }

  els.qrLoading.style.display = 'flex';
  els.qrError.style.display = 'none';
  els.qrCanvas.style.display = 'none';
  els.statusWaiting.style.display = 'block';
  els.statusSuccess.style.display = 'none';
  els.dlgSave.disabled = true;

  try {
    // Simula geração de sessão QR (em produção, viria da API)
    qrSessionId = `qr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const qrData = JSON.stringify({
      session: qrSessionId,
      timestamp: Date.now(),
      type: 'telegram_web'
    });

    await QRCode.toCanvas(els.qrCanvas, qrData, {
      width: 256,
      margin: 2,
      color: {
        dark: '#1c1633',
        light: '#ffffff'
      }
    });

    els.qrCanvas.style.display = 'block';
    els.qrLoading.style.display = 'none';
    startQRPolling();

  } catch (err) {
    console.error('QR Code generation error:', err);
    els.qrLoading.style.display = 'none';
    els.qrError.style.display = 'flex';
  }
}

function startQRPolling() {
  stopQRPolling();
  
  // Simula polling para verificar se QR foi escaneado
  // Em produção, isso seria uma chamada à API
  let attempts = 0;
  const maxAttempts = 120; // 2 minutos (1s por tentativa)
  
  qrPollInterval = setInterval(() => {
    attempts++;
    
    // Simula sucesso após 10 segundos (em produção, verifica API)
    if (attempts === 10) {
      stopQRPolling();
      els.statusWaiting.style.display = 'none';
      els.statusSuccess.style.display = 'block';
      els.dlgSave.disabled = false;
      els.dlgSave.textContent = 'Finalizar conexão';
    } else if (attempts >= maxAttempts) {
      stopQRPolling();
      els.statusWaiting.innerHTML = `
        <span class="icon" data-icon="circle-x"></span>
        <p>QR Code expirado. Gere um novo.</p>
      `;
      els.qrRetry.style.display = 'block';
    }
  }, 1000);
}

function stopQRPolling() {
  if (qrPollInterval) {
    clearInterval(qrPollInterval);
    qrPollInterval = null;
  }
}

els.qrRetry?.addEventListener('click', () => {
  generateQRCode();
});

// ==== ABRIR/FECHAR MODAL ====
function openConnDialog(edit = null) {
  els.dlg.hidden = false;
  switchConnTab('token');
  
  if (edit) {
    els.dlg.querySelector('h3').textContent = 'Editar conexão';
    els.connName.value = edit.name || '';
    els.connMethod.value = edit.method || 'token';
    els.connToken.value = edit.token || '';
    els.connPhone.value = edit.phone || '';
    els.connMethod.dispatchEvent(new Event('change'));
  } else {
    els.dlg.querySelector('h3').textContent = 'Nova conexão Telegram';
    els.connName.value = '';
    els.connMethod.value = 'token';
    els.connToken.value = '';
    els.connPhone.value = '';
    els.connCode.value = '';
    els.connMethod.dispatchEvent(new Event('change'));
  }
  
  els.connName.focus();
}

function closeConnDialog() {
  els.dlg.hidden = true;
  stopQRPolling();
  els.codeField.style.display = 'none';
  els.dlgSave.disabled = false;
  els.dlgSave.textContent = 'Conectar';
}

// ==== SALVAR CONEXÃO ====
els.dlgSave?.addEventListener('click', () => {
  if (currentMethod === 'qr') {
    const name = els.connQrName.value.trim();
    if (!name) return;
    
    const newConn = {
      id: Math.max(0, ...connections.map(c => c.id)) + 1,
      name,
      method: 'qr',
      connected: true,
      identifier: qrSessionId,
      createdAt: Date.now()
    };
    
    connections.push(newConn);
    saveToStorage('telegram_connections', connections);
    render();
    closeConnDialog();
    return;
  }

  // Método Token/Telefone
  const name = els.connName.value.trim();
  const method = els.connMethod.value;
  
  if (!name) return;
  
  if (method === 'token') {
    const token = els.connToken.value.trim();
    if (!token) return;
    
    const newConn = {
      id: Math.max(0, ...connections.map(c => c.id)) + 1,
      name,
      method: 'token',
      token,
      connected: true,
      identifier: token.substring(0, 20) + '...',
      createdAt: Date.now()
    };
    
    connections.push(newConn);
  } else if (method === 'phone') {
    const phone = els.connPhone.value.trim();
    const code = els.connCode.value.trim();
    
    if (!phone) return;
    if (!code) {
      // Primeira etapa: solicitar código
      els.codeField.style.display = 'block';
      els.dlgSave.textContent = 'Verificar código';
      // Em produção, aqui faria a chamada à API para solicitar código
      alert('Código de verificação enviado para ' + phone);
      return;
    }
    
    // Segunda etapa: verificar código e conectar
    const newConn = {
      id: Math.max(0, ...connections.map(c => c.id)) + 1,
      name,
      method: 'phone',
      phone,
      connected: true,
      identifier: phone,
      createdAt: Date.now()
    };
    
    connections.push(newConn);
  }
  
  saveToStorage('telegram_connections', connections);
  render();
  closeConnDialog();
});

els.dlgCancel?.addEventListener('click', closeConnDialog);

// ==== AÇÕES DA TABELA ====
els.tbody?.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-toggle],button[data-edit],button[data-del]');
  if (!btn) return;

  const id = Number(btn.dataset.toggle || btn.dataset.edit || btn.dataset.del);
  const conn = connections.find(c => c.id === id);
  if (!conn) return;

  if (btn.dataset.toggle) {
    pendingDiscId = id;
    els.discDlg.hidden = false;
  } else if (btn.dataset.edit) {
    openConnDialog(conn);
  } else if (btn.dataset.del) {
    pendingDeleteId = id;
    els.delDlg.hidden = false;
  }
});

// ==== EXCLUIR ====
els.delCancel?.addEventListener('click', () => {
  pendingDeleteId = null;
  els.delDlg.hidden = true;
});

els.delConfirm?.addEventListener('click', () => {
  if (pendingDeleteId != null) {
    connections = connections.filter(c => c.id !== pendingDeleteId);
    saveToStorage('telegram_connections', connections);
    render();
    pendingDeleteId = null;
  }
  els.delDlg.hidden = true;
});

// ==== DESCONECTAR/CONECTAR ====
els.discCancel?.addEventListener('click', () => {
  pendingDiscId = null;
  els.discDlg.hidden = true;
});

els.discConfirm?.addEventListener('click', () => {
  if (pendingDiscId != null) {
    const idx = connections.findIndex(c => c.id === pendingDiscId);
    if (idx > -1) {
      connections[idx].connected = !connections[idx].connected;
      saveToStorage('telegram_connections', connections);
      render();
    }
    pendingDiscId = null;
  }
  els.discDlg.hidden = true;
});

// ==== LOGOUT ====
els.logoutBtn?.addEventListener('click', () => {
  els.logoutDialog.hidden = false;
});

els.logoutCancel?.addEventListener('click', () => {
  els.logoutDialog.hidden = true;
});

els.logoutConfirm?.addEventListener('click', () => {
  localStorage.removeItem('nexhelp_auth');
  window.location.href = 'index.html';
});

// ==== NOVA CONEXÃO ====
els.newBtn?.addEventListener('click', () => openConnDialog());

// ==== FECHAR MODAIS ====
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('backdrop')) {
    els.dlg.hidden = true;
    els.delDlg.hidden = true;
    els.discDlg.hidden = true;
    els.logoutDialog.hidden = true;
    stopQRPolling();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (!els.dlg.hidden) closeConnDialog();
    if (!els.delDlg.hidden) els.delDlg.hidden = true;
    if (!els.discDlg.hidden) els.discDlg.hidden = true;
    if (!els.logoutDialog.hidden) els.logoutDialog.hidden = true;
  }
});

// ==== INICIALIZAÇÃO ====
render();
