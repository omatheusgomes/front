// js/configuracoes.js
const els = {
  // Abas
  tabs: document.querySelectorAll('.tab'),
  tabsUnderline: document.getElementById('tabsUnderline'),
  configTrack: document.getElementById('configTrack'),
  panels: {
    categories: document.getElementById('panel-categories'),
    queues: document.getElementById('panel-queues'),
    general: document.getElementById('panel-general')
  },

  // Categorias
  categorySearch: document.getElementById('categorySearch'),
  newCategoryBtn: document.getElementById('newCategoryBtn'),
  categoriesTbody: document.getElementById('categoriesTbody'),
  categoryCounter: document.getElementById('categoryCounter'),
  categoryDialog: document.getElementById('categoryDialog'),
  categoryForm: document.getElementById('categoryForm'),
  categoryName: document.getElementById('categoryName'),
  categoryDesc: document.getElementById('categoryDesc'),
  categoryActive: document.getElementById('categoryActive'),
  categoryEditingId: document.getElementById('categoryEditingId'),
  categoryDlgCancel: document.getElementById('categoryDlgCancel'),
  categoryDlgSave: document.getElementById('categoryDlgSave'),

  // Filas
  queueSearch: document.getElementById('queueSearch'),
  newQueueBtn: document.getElementById('newQueueBtn'),
  queuesTbody: document.getElementById('queuesTbody'),
  queueCounter: document.getElementById('queueCounter'),
  queueDialog: document.getElementById('queueDialog'),
  queueForm: document.getElementById('queueForm'),
  queueName: document.getElementById('queueName'),
  queueDesc: document.getElementById('queueDesc'),
  queueUsers: document.getElementById('queueUsers'),
  queueActive: document.getElementById('queueActive'),
  queueEditingId: document.getElementById('queueEditingId'),
  queueDlgCancel: document.getElementById('queueDlgCancel'),
  queueDlgSave: document.getElementById('queueDlgSave'),

  // Geral
  generalForm: document.getElementById('generalForm'),

  // Confirmar exclusão
  confirmDialog: document.getElementById('confirmDialog'),
  confirmTitle: document.getElementById('confirmTitle'),
  confirmMessage: document.getElementById('confirmMessage'),
  confirmCancel: document.getElementById('confirmCancel'),
  confirmDelete: document.getElementById('confirmDelete'),

  // Logout
  logoutBtn: document.getElementById('logoutBtn'),
  logoutDialog: document.getElementById('logoutDialog'),
  logoutCancel: document.getElementById('logoutCancel'),
  logoutConfirm: document.getElementById('logoutConfirm')
};

/* ==== STATE ==== */
const state = {
  currentTab: 'categories',
  categories: [],
  queues: [],
  users: ['Matheus', 'Ana', 'Pedro', 'Carlos', 'Julia'], // Mock - viria da API
  deleteCallback: null
};

/* ==== UTILS ==== */
function esc(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[m]);
}

function loadFromStorage(key, defaultValue = []) {
  try {
    const raw = localStorage.getItem(`nexhelp_${key}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return defaultValue;
}

function saveToStorage(key, data) {
  try {
    localStorage.setItem(`nexhelp_${key}`, JSON.stringify(data));
  } catch {}
}

/* ==== SEED DATA ==== */
(function seed() {
  state.categories = loadFromStorage('categories', [
    { id: 1, name: 'Suporte Técnico', desc: 'Problemas técnicos e dúvidas', active: true },
    { id: 2, name: 'Financeiro', desc: 'Questões relacionadas a pagamentos e faturas', active: true },
    { id: 3, name: 'Comercial', desc: 'Vendas e informações comerciais', active: true },
    { id: 4, name: 'Cancelamento', desc: 'Solicitações de cancelamento', active: false }
  ]);

  state.queues = loadFromStorage('queues', [
    { id: 1, name: 'Suporte', desc: 'Fila de suporte técnico', users: ['Matheus', 'Ana'], active: true },
    { id: 2, name: 'Financeiro', desc: 'Fila de atendimento financeiro', users: ['Pedro'], active: true },
    { id: 3, name: 'Comercial', desc: 'Fila de vendas', users: ['Carlos', 'Julia'], active: true }
  ]);
})();

/* ==== ABAS ==== */
function moveUnderline() {
  const activeTab = document.querySelector('.tab.is-active');
  if (!activeTab || !els.tabsUnderline) return;
  els.tabsUnderline.style.width = activeTab.offsetWidth + 'px';
  els.tabsUnderline.style.transform = `translateX(${activeTab.offsetLeft}px)`;
}

function switchTab(tabName) {
  state.currentTab = tabName;
  
  els.tabs.forEach((tab) => {
    const isActive = tab.id === `tab-${tabName}`;
    tab.classList.toggle('is-active', isActive);
    tab.setAttribute('aria-selected', isActive);
  });

  // Atualiza painéis
  Object.keys(els.panels).forEach(key => {
    const panel = els.panels[key];
    if (panel) {
      panel.setAttribute('aria-hidden', key !== tabName);
    }
  });

  // Move underline
  moveUnderline();

  // Move track
  const tabIndex = ['categories', 'queues', 'general'].indexOf(tabName);
  if (els.configTrack) {
    els.configTrack.style.transform = `translateX(-${tabIndex * 100}%)`;
  }
}

els.tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const tabName = tab.id.replace('tab-', '');
    switchTab(tabName);
  });
});

window.addEventListener('resize', moveUnderline);

// Inicializa
setTimeout(() => {
  switchTab('categories');
  moveUnderline();
}, 100);

/* ==== CATEGORIAS ==== */
function renderCategories(filter = '') {
  const filtered = state.categories.filter(cat => {
    if (!filter) return true;
    const search = filter.toLowerCase();
    return cat.name.toLowerCase().includes(search) ||
           (cat.desc || '').toLowerCase().includes(search);
  });

  els.categoriesTbody.innerHTML = filtered.map(cat => `
    <tr role="row">
      <td>${cat.id}</td>
      <td><strong>${esc(cat.name)}</strong></td>
      <td>${esc(cat.desc || '—')}</td>
      <td>
        <span class="status-badge ${cat.active ? 'active' : 'inactive'}">
          ${cat.active ? 'Ativa' : 'Inativa'}
        </span>
      </td>
      <td class="actions-cell">
        <button class="icon-btn sm" title="Editar" data-action="edit" data-id="${cat.id}">
          <span class="icon" data-icon="pencil"></span>
        </button>
        <button class="icon-btn sm danger" title="Excluir" data-action="delete" data-id="${cat.id}">
          <span class="icon" data-icon="trash-2"></span>
        </button>
      </td>
    </tr>
  `).join('');

  els.categoryCounter.textContent = `${filtered.length} categoria(s)`;

  // Event listeners
  els.categoriesTbody.querySelectorAll('[data-action="edit"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const cat = state.categories.find(c => c.id === id);
      if (cat) openCategoryDialog(cat);
    });
  });

  els.categoriesTbody.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const cat = state.categories.find(c => c.id === id);
      if (cat) confirmDelete('categoria', cat.name, () => {
        state.categories = state.categories.filter(c => c.id !== id);
        saveToStorage('categories', state.categories);
        renderCategories(els.categorySearch.value);
      });
    });
  });
}

function openCategoryDialog(edit = null) {
  els.categoryDialog.hidden = false;
  
  if (edit) {
    els.categoryDialog.querySelector('h3').textContent = 'Editar categoria';
    els.categoryDlgSave.textContent = 'Salvar';
    els.categoryEditingId.value = String(edit.id);
    els.categoryName.value = edit.name || '';
    els.categoryDesc.value = edit.desc || '';
    els.categoryActive.checked = edit.active !== false;
  } else {
    els.categoryDialog.querySelector('h3').textContent = 'Nova categoria';
    els.categoryDlgSave.textContent = 'Adicionar';
    els.categoryEditingId.value = '';
    els.categoryName.value = '';
    els.categoryDesc.value = '';
    els.categoryActive.checked = true;
  }
  
  els.categoryName.focus();
}

function closeCategoryDialog() {
  els.categoryDialog.hidden = true;
}

els.categoryForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = els.categoryName.value.trim();
  if (!name) return;

  const editingId = els.categoryEditingId.value;
  const data = {
    name,
    desc: els.categoryDesc.value.trim(),
    active: els.categoryActive.checked
  };

  if (editingId) {
    const id = parseInt(editingId);
    const idx = state.categories.findIndex(c => c.id === id);
    if (idx > -1) {
      state.categories[idx] = { ...state.categories[idx], ...data };
    }
  } else {
    const newId = Math.max(0, ...state.categories.map(c => c.id)) + 1;
    state.categories.push({ id: newId, ...data });
  }

  saveToStorage('categories', state.categories);
  renderCategories(els.categorySearch.value);
  closeCategoryDialog();
});

els.categoryDlgCancel.addEventListener('click', closeCategoryDialog);
els.newCategoryBtn.addEventListener('click', () => openCategoryDialog());

els.categorySearch.addEventListener('input', (e) => {
  renderCategories(e.target.value);
});

/* ==== FILAS ==== */
function fillQueueUsersSelect() {
  els.queueUsers.innerHTML = state.users.map(user => 
    `<option value="${esc(user)}">${esc(user)}</option>`
  ).join('');
}

function renderQueues(filter = '') {
  const filtered = state.queues.filter(queue => {
    if (!filter) return true;
    const search = filter.toLowerCase();
    return queue.name.toLowerCase().includes(search) ||
           (queue.desc || '').toLowerCase().includes(search);
  });

  els.queuesTbody.innerHTML = filtered.map(queue => `
    <tr role="row">
      <td>${queue.id}</td>
      <td><strong>${esc(queue.name)}</strong></td>
      <td>${esc(queue.desc || '—')}</td>
      <td>${queue.users.length} usuário(s)</td>
      <td>
        <span class="status-badge ${queue.active ? 'active' : 'inactive'}">
          ${queue.active ? 'Ativa' : 'Inativa'}
        </span>
      </td>
      <td class="actions-cell">
        <button class="icon-btn sm" title="Editar" data-action="edit" data-id="${queue.id}">
          <span class="icon" data-icon="pencil"></span>
        </button>
        <button class="icon-btn sm danger" title="Excluir" data-action="delete" data-id="${queue.id}">
          <span class="icon" data-icon="trash-2"></span>
        </button>
      </td>
    </tr>
  `).join('');

  els.queueCounter.textContent = `${filtered.length} fila(s)`;

  // Event listeners
  els.queuesTbody.querySelectorAll('[data-action="edit"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const queue = state.queues.find(q => q.id === id);
      if (queue) openQueueDialog(queue);
    });
  });

  els.queuesTbody.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const queue = state.queues.find(q => q.id === id);
      if (queue) confirmDelete('fila', queue.name, () => {
        state.queues = state.queues.filter(q => q.id !== id);
        saveToStorage('queues', state.queues);
        renderQueues(els.queueSearch.value);
      });
    });
  });
}

function openQueueDialog(edit = null) {
  fillQueueUsersSelect();
  els.queueDialog.hidden = false;
  
  if (edit) {
    els.queueDialog.querySelector('h3').textContent = 'Editar fila';
    els.queueDlgSave.textContent = 'Salvar';
    els.queueEditingId.value = String(edit.id);
    els.queueName.value = edit.name || '';
    els.queueDesc.value = edit.desc || '';
    els.queueActive.checked = edit.active !== false;
    
    // Seleciona usuários
    [...els.queueUsers.options].forEach(opt => {
      opt.selected = (edit.users || []).includes(opt.value);
    });
  } else {
    els.queueDialog.querySelector('h3').textContent = 'Nova fila';
    els.queueDlgSave.textContent = 'Adicionar';
    els.queueEditingId.value = '';
    els.queueName.value = '';
    els.queueDesc.value = '';
    els.queueActive.checked = true;
    [...els.queueUsers.options].forEach(opt => opt.selected = false);
  }
  
  els.queueName.focus();
}

function closeQueueDialog() {
  els.queueDialog.hidden = true;
}

els.queueForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = els.queueName.value.trim();
  if (!name) return;

  const editingId = els.queueEditingId.value;
  const selectedUsers = [...els.queueUsers.selectedOptions].map(opt => opt.value);
  
  const data = {
    name,
    desc: els.queueDesc.value.trim(),
    users: selectedUsers,
    active: els.queueActive.checked
  };

  if (editingId) {
    const id = parseInt(editingId);
    const idx = state.queues.findIndex(q => q.id === id);
    if (idx > -1) {
      state.queues[idx] = { ...state.queues[idx], ...data };
    }
  } else {
    const newId = Math.max(0, ...state.queues.map(q => q.id)) + 1;
    state.queues.push({ id: newId, ...data });
  }

  saveToStorage('queues', state.queues);
  renderQueues(els.queueSearch.value);
  closeQueueDialog();
});

els.queueDlgCancel.addEventListener('click', closeQueueDialog);
els.newQueueBtn.addEventListener('click', () => openQueueDialog());

els.queueSearch.addEventListener('input', (e) => {
  renderQueues(e.target.value);
});

/* ==== CONFIGURAÇÕES GERAIS ==== */
function loadGeneralSettings() {
  const settings = loadFromStorage('general_settings', {
    timeoutResponse: 30,
    notifyNew: true,
    notifyTransfer: true,
    notifyTimeout: false,
    itemsPerPage: 25,
    autoRefresh: true
  });

  els.generalForm.querySelector('#timeoutResponse').value = settings.timeoutResponse || 30;
  els.generalForm.querySelector('#notifyNew').checked = settings.notifyNew !== false;
  els.generalForm.querySelector('#notifyTransfer').checked = settings.notifyTransfer !== false;
  els.generalForm.querySelector('#notifyTimeout').checked = settings.notifyTimeout || false;
  els.generalForm.querySelector('#itemsPerPage').value = settings.itemsPerPage || 25;
  els.generalForm.querySelector('#autoRefresh').checked = settings.autoRefresh !== false;
}

els.generalForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const settings = {
    timeoutResponse: parseInt(els.generalForm.querySelector('#timeoutResponse').value) || 30,
    notifyNew: els.generalForm.querySelector('#notifyNew').checked,
    notifyTransfer: els.generalForm.querySelector('#notifyTransfer').checked,
    notifyTimeout: els.generalForm.querySelector('#notifyTimeout').checked,
    itemsPerPage: parseInt(els.generalForm.querySelector('#itemsPerPage').value) || 25,
    autoRefresh: els.generalForm.querySelector('#autoRefresh').checked
  };

  saveToStorage('general_settings', settings);
  alert('Configurações salvas com sucesso!');
});

/* ==== CONFIRMAR EXCLUSÃO ==== */
function confirmDelete(type, name, callback) {
  els.confirmTitle.textContent = `Excluir ${type}?`;
  els.confirmMessage.textContent = `Tem certeza que deseja excluir "${name}"? Essa ação não poderá ser desfeita.`;
  els.confirmDialog.hidden = false;
  state.deleteCallback = callback;
}

els.confirmCancel.addEventListener('click', () => {
  els.confirmDialog.hidden = true;
  state.deleteCallback = null;
});

els.confirmDelete.addEventListener('click', () => {
  if (state.deleteCallback) {
    state.deleteCallback();
    els.confirmDialog.hidden = true;
    state.deleteCallback = null;
  }
});

/* ==== MENU DE PERFIL ==== */
const profileBtn = document.getElementById('profileBtn');
const profileMenu = document.getElementById('profileMenu');

profileBtn?.addEventListener('click', (e) => {
  e.stopPropagation();
  const isOpen = !profileMenu.hidden;
  profileMenu.hidden = isOpen;
  profileBtn.setAttribute('aria-expanded', !isOpen);
});

document.addEventListener('click', (e) => {
  if (profileMenu && !profileMenu.contains(e.target) && !profileBtn?.contains(e.target)) {
    profileMenu.hidden = true;
    profileBtn?.setAttribute('aria-expanded', 'false');
  }
});

/* ==== LOGOUT ==== */
els.logoutBtn?.addEventListener('click', () => {
  els.logoutDialog.hidden = false;
  profileMenu.hidden = true;
  profileBtn?.setAttribute('aria-expanded', 'false');
});

els.logoutCancel?.addEventListener('click', () => {
  els.logoutDialog.hidden = true;
});

els.logoutConfirm?.addEventListener('click', () => {
  localStorage.removeItem('nexhelp_auth');
  window.location.href = 'index.html';
});

/* ==== INICIALIZAÇÃO ==== */
renderCategories();
renderQueues();
loadGeneralSettings();

