// js/openai.js
// Mantém o padrão das outras telas: sem recriar layout, só lógica da página.

const els = {
  tbody: document.getElementById('openaiTbody'),
  counterTop: document.getElementById('promptCounterTop'),
  counterBottom: document.getElementById('promptCounterBottom'),
  newBtn: document.getElementById('newPromptBtn'),

  dlg: document.getElementById('promptDialog'),
  dlgTitle: document.getElementById('promptDialogTitle'),
  dlgCancel: document.getElementById('dlgCancel'),
  dlgSave: document.getElementById('dlgSave'),
  editingId: document.getElementById('editingId'),

  promptName: document.getElementById('promptName'),
  apiKey: document.getElementById('apiKey'),
  toggleApi: document.getElementById('toggleApi'),
  eyeIcon: document.getElementById('eyeIcon'),
  queueSelect: document.getElementById('queueSelect'),
  maxTokens: document.getElementById('maxTokens'),
  maxHistory: document.getElementById('maxHistory'),

  confirmDlg: document.getElementById('confirmDialog'),
  confirmCancel: document.getElementById('confirmCancel'),
  confirmDelete: document.getElementById('confirmDelete'),
};

let pendingDeleteId = null;

// Mock inicial (substitua por integração real)
const ALL_QUEUES = ['Suporte', 'Financeiro', 'Comercial', 'CS'];
let prompts = []; // estado local

function esc(s) {
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* ---------- Render ---------- */
function render() {
  els.tbody.innerHTML = prompts.map(p => `
    <tr>
      <td class="col-name"><strong title="${esc(p.name)}">${esc(p.name)}</strong></td>
      <td class="col-queues">${esc((p.queues||[]).join(', ') || '—')}</td>
      <td class="col-max">${Number(p.maxTokens || 0)}</td>
      <td class="col-actions">
        <div class="actions-cell">
          <button class="icon-btn ghost sm" title="Editar" data-edit="${p.id}" type="button" aria-label="Editar">
            <span class="icon" data-icon="square-pen"></span>
          </button>
          <button class="icon-btn ghost sm danger" title="Excluir" data-del="${p.id}" type="button" aria-label="Excluir">
            <span class="icon" data-icon="trash-2"></span>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  const text = `${prompts.length} ${prompts.length === 1 ? 'prompt' : 'prompts'}`;
  els.counterTop.textContent = text;
  els.counterBottom.textContent = text;
}

function fillQueueSelect() {
  els.queueSelect.innerHTML = ALL_QUEUES.map(q => `<option value="${esc(q)}">${esc(q)}</option>`).join('');
}

/* ---------- Dialog novo/editar ---------- */
function openDialog(edit) {
  els.dlg.hidden = false;

  if (edit) {
    els.dlgTitle.textContent = 'Editar Prompt';
    els.dlgSave.textContent = 'Salvar';
    els.editingId.value = String(edit.id);
    els.promptName.value = edit.name || '';
    els.apiKey.value = edit.apiKey || '';
    els.maxTokens.value = edit.maxTokens ?? 100;
    els.maxHistory.value = edit.maxHistory ?? 10;
    [...els.queueSelect.options].forEach(o => o.selected = (edit.queues||[]).includes(o.value));
  } else {
    els.dlgTitle.textContent = 'Adicionar Prompt';
    els.dlgSave.textContent = 'Adicionar';
    els.editingId.value = '';
    els.promptName.value = '';
    els.apiKey.value = '';
    els.maxTokens.value = 100;
    els.maxHistory.value = 10;
    [...els.queueSelect.options].forEach(o => o.selected = false);
  }

  // Reseta olho
  els.apiKey.type = 'password';
  els.eyeIcon.setAttribute('data-icon', 'eye');
  els.promptName.focus();
}
function closeDialog(){ els.dlg.hidden = true; }

els.newBtn.addEventListener('click', () => openDialog(null));
els.dlgCancel.addEventListener('click', closeDialog);

els.dlgSave.addEventListener('click', () => {
  const name = els.promptName.value.trim();
  const apiKey = els.apiKey.value.trim();
  if (!name || !apiKey) return;

  const selectedQueues = [...els.queueSelect.selectedOptions].map(o => o.value);
  const maxTokens = Math.max(1, Number(els.maxTokens.value || 100));
  const maxHistory = Math.max(1, Number(els.maxHistory.value || 10));

  const editing = els.editingId.value.trim();
  if (editing) {
    const idx = prompts.findIndex(p => String(p.id) === editing);
    if (idx > -1) Object.assign(prompts[idx], { name, apiKey, queues: selectedQueues, maxTokens, maxHistory });
  } else {
    const nextId = (prompts.reduce((m,p)=>Math.max(m,p.id),0) || 0) + 1;
    prompts.unshift({ id: nextId, name, apiKey, queues: selectedQueues, maxTokens, maxHistory });
  }

  closeDialog();
  render();
});

// Mostrar/ocultar API Key
els.toggleApi.addEventListener('click', () => {
  const showing = els.apiKey.type !== 'password';
  els.apiKey.type = showing ? 'password' : 'text';
  els.eyeIcon.setAttribute('data-icon', showing ? 'eye' : 'eye-off');
});

/* ---------- Tabela: ações ---------- */
els.tbody.addEventListener('click', e => {
  const btn = e.target.closest('button[data-edit],button[data-del]');
  if (!btn) return;
  const id = Number(btn.dataset.edit || btn.dataset.del);
  const row = prompts.find(p => p.id === id);
  if (!row) return;

  if (btn.dataset.edit) openDialog(row);
  if (btn.dataset.del) { pendingDeleteId = id; openConfirm(); }
});

/* ---------- Confirmar exclusão ---------- */
function openConfirm(){ els.confirmDlg.hidden = false; }
function closeConfirm(){ els.confirmDlg.hidden = true; pendingDeleteId = null; }
els.confirmCancel.addEventListener('click', closeConfirm);
els.confirmDelete.addEventListener('click', () => {
  if (pendingDeleteId != null) {
    prompts = prompts.filter(p => p.id !== pendingDeleteId);
    render();
  }
  closeConfirm();
});

/* ---------- UX ---------- */
// Fecha modais ao clicar no backdrop
document.addEventListener('click', (e) => {
  if (e.target.matches('#promptDialog .backdrop')) closeDialog();
  if (e.target.matches('#confirmDialog .backdrop')) closeConfirm();
});
// ESC fecha modais
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (!els.dlg.hidden) closeDialog();
    if (!els.confirmDlg.hidden) closeConfirm();
  }
});

/* ---------- Init ---------- */
fillQueueSelect();
render();
