import { getSession, clearSession } from './services/auth.js';

// Chame nas páginas privadas
export function requireAuth() {
  const sess = getSession();
  if (!sess || !sess.token) {
    window.location.href = 'index.html';
  }
}

// Botão de sair
export function setupLogout(selector = '#logout') {
  const btn = document.querySelector(selector);
  if (!btn) return;
  btn.addEventListener('click', () => {
    clearSession();
    window.location.href = 'index.html';
  });
}

