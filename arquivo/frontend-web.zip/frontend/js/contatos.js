// js/contatos.js
const els = {
  tagWrap: document.getElementById('tagWrap'),
  tagFilter: document.getElementById('tagFilter'),
  tagChevron: document.getElementById('tagChevron'),

  searchbox: document.getElementById('searchbox'),
  searchIcon: document.getElementById('searchIcon'),
  search: document.getElementById('contactsSearch'),

  tbody: document.getElementById('contactsTbody'),
  counter: document.getElementById('contactsCounter'),
  addBtn: document.getElementById('addContactBtn'),

  dialog: document.getElementById('contactDialog'),
  dlgCancel: document.getElementById('contactDlgCancel'),
  dlgSave: document.getElementById('contactDlgSave'),

  profileBtn: document.getElementById('profileBtn'),
  profileMenu: document.getElementById('profileMenu'),
  myProfileBtn: document.getElementById('myProfileBtn'),
  logoutBtn: document.getElementById('logoutBtn'),
};

const state = { query:'', tag:'all' };

const onlyDigits = (s) => (s||'').replace(/\D+/g,'');
// normaliza e remove acentos (compatível amplamente)
const norm = (s) => String(s||'')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g,'')
  .toLowerCase();

// dataset de contatos — INICIAR VAZIO
let contacts = [];

function esc(s){ return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }

function buildTagFilter(){
  const set = new Set();
  contacts.forEach(c => (c.tags||[]).forEach(t => set.add(t)));
  const options = ['all', ...[...set].sort((a,b)=>a.localeCompare(b,'pt-BR'))];
  els.tagFilter.innerHTML = options.map(v =>
    v==='all' ? '<option value="all">Todas as tags</option>' : `<option value="${esc(v)}">${esc(v)}</option>`
  ).join('');
}

function render(){
  const qTxt = norm(state.query);           // texto normalizado (nome)
  const qNum = onlyDigits(state.query);     // dígitos (telefone)

  const rows = contacts.filter(c=>{
    const matchesTag = (state.tag==='all') || (c.tags||[]).includes(state.tag);
    if (!matchesTag) return false;
    if (!qTxt && !qNum) return true;

    const nameHit  = qTxt ? norm(c.name).includes(qTxt) : false;
    const phoneHit = qNum ? onlyDigits(c.phone).includes(qNum) : false;
    return nameHit || phoneHit;
  });

  els.tbody.innerHTML = rows.map(c=>{
    const avatar = c.avatar
      ? `<img src="${esc(c.avatar)}" alt="">`
      : `<span class="icon" data-icon="book-user" aria-hidden="true"></span>`;
    return `
      <tr role="row" data-id="${c.id}">
        <td class="col-name">
          <div class="name-cell">
            <span class="avatar">${avatar}</span>
            <div class="name-main">
              <div class="name" title="${esc(c.name)}">${esc(c.name)}</div>
              ${c.tags?.length ? `<div class="sub">${esc(c.tags.join(', '))}</div>` : ''}
            </div>
          </div>
        </td>
        <td class="col-number">${esc(c.phone||'—')}</td>
        <td class="col-email">${c.email ? esc(c.email) : '—'}</td>
        <td class="col-actions">
          <div class="actions-cell">
            <button class="icon-btn ghost sm" title="Editar" data-edit="${c.id}">
              <span class="icon" data-icon="pencil"></span>
            </button>
            <button class="icon-btn ghost sm warn" title="Bloquear" data-block="${c.id}">
              <span class="icon" data-icon="ban"></span>
            </button>
            <button class="icon-btn ghost sm danger" title="Excluir" data-del="${c.id}">
              <span class="icon" data-icon="trash-2"></span>
            </button>
          </div>
        </td>
      </tr>`;
  }).join('');

  els.counter.textContent = `${rows.length} ${rows.length===1?'contato':'contatos'}`;
  document.dispatchEvent(new CustomEvent('icons:refresh'));
}

/* filtro por tag */
els.tagFilter?.addEventListener('change', ()=>{ state.tag = els.tagFilter.value || 'all'; render(); });
els.tagFilter?.addEventListener('focus', ()=>{
  els.tagWrap.classList.add('open');
  els.tagChevron.setAttribute('data-icon','chevron-up');
  document.dispatchEvent(new CustomEvent('icons:refresh'));
});
els.tagFilter?.addEventListener('blur', ()=>{
  els.tagWrap.classList.remove('open');
  els.tagChevron.setAttribute('data-icon','chevron-down');
  document.dispatchEvent(new CustomEvent('icons:refresh'));
});

/* busca */
function updateSearchUI(){
  const has = !!els.search.value.trim();
  els.searchbox.classList.toggle('has-value', has);
}
els.search?.addEventListener('input', ()=>{
  state.query = els.search.value || '';
  updateSearchUI();
  render();
});
els.searchIcon?.addEventListener('click', ()=>{
  if (els.search.value.trim()){
    els.search.value = '';
    state.query = '';
    updateSearchUI();
    render();
    els.search.focus();
  }else{
    els.search.focus();
  }
});

/* ações */
els.tbody?.addEventListener('click', (e)=>{
  const btn = e.target.closest('button[data-edit],button[data-block],button[data-del]');
  if (!btn) return;
  const id = Number(btn.dataset.edit || btn.dataset.block || btn.dataset.del);
  const idx = contacts.findIndex(x=>x.id===id);
  if (idx<0) return;

  if (btn.dataset.edit){
    openContactDialog('Editar contato');
    return;
  }
  if (btn.dataset.block){
    const c = contacts[idx];
    c.blocked = !c.blocked;
    btn.classList.toggle('danger', c.blocked);
    btn.title = c.blocked ? 'Desbloquear' : 'Bloquear';
    return;
  }
  if (btn.dataset.del){
    if (confirm('Deseja realmente excluir este contato?')){
      contacts.splice(idx,1);
      buildTagFilter();
      render();
    }
    return;
  }
});

/* modal */
function openContactDialog(title){
  document.getElementById('contactDialogTitle').textContent = title || 'Novo contato';
  document.getElementById('contactDialog').hidden = false;
}
els.addBtn?.addEventListener('click', ()=> openContactDialog('Novo contato'));
document.getElementById('contactDlgCancel')?.addEventListener('click', ()=> document.getElementById('contactDialog').hidden = true);
document.getElementById('contactDlgSave')?.addEventListener('click', ()=> document.getElementById('contactDialog').hidden = true);

/* perfil/logout */
function togglePanel(btn, panel){
  const will = panel.hasAttribute('hidden');
  panel.toggleAttribute('hidden', !will);
  if (will){
    setTimeout(()=>{
      const closer=(e)=>{ if(!panel.contains(e.target) && e.target!==btn){ panel.hidden=true; document.removeEventListener('click', closer);} };
      document.addEventListener('click', closer);
    },0);
  }
}
els.profileBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); togglePanel(els.profileBtn, els.profileMenu); });
els.logoutBtn?.addEventListener('click', ()=>{ try{localStorage.removeItem('nexhelp_auth');}catch{} location.href='index.html'; });

/* init */
buildTagFilter();
updateSearchUI();
render();
